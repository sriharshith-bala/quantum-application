"""
kpi_benchmark.py — Measures every KPI required by the task and writes the
results to results/kpi_results.json plus PNG plots.

KPIs covered:
  1. Execution time            — wall clock per circuit, vs qubit count
  2. Memory usage              — theoretical 16*2^n and measured process RSS
  3. Number of qubits supported— empirical ceiling on this machine
  4. Probability correctness   — norm drift and TVD vs analytic distributions
  5. State vector size         — amplitude count and bytes
  6. Gate execution time       — per-gate-type cost, vs qubit count

Methodology notes:
  - Timings use time.perf_counter (monotonic, highest available resolution).
  - Each measurement is repeated and we report the **median**, not the mean:
    medians are robust to OS scheduling spikes, which are common on a shared
    container.
  - Small-n timings are dominated by fixed Python/NumPy call overhead, not by
    the 2^n arithmetic. We measure that overhead floor explicitly so the
    scaling discussion is honest about where the exponential actually kicks in.
  - `validate=False` in the scaling runs: the post-gate normalisation check is
    itself an O(2^n) pass and would otherwise double the measured cost.

Run:  python benchmarks/kpi_benchmark.py
"""

from __future__ import annotations

import gc
import json
import os
import platform
import statistics
import sys
import time

import numpy as np
import psutil

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from quantum_sim import (  # noqa: E402
    Circuit, QuantumState, sample, counts_to_frequencies,
    total_variation_distance,
)
import quantum_sim.gates as g  # noqa: E402

RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")
BYTES_PER_AMPLITUDE = 16  # complex128

# Scaling sweep. 24 qubits = 268 MB for the vector alone; gate application
# allocates a temporary of the same size, so peak is roughly double.
MAX_QUBITS_SWEEP = 24
SWEEP = list(range(1, MAX_QUBITS_SWEEP + 1))


def _repeat(fn, n_repeat: int) -> list[float]:
    """Time `fn` n_repeat times, returning raw per-call seconds."""
    out = []
    for _ in range(n_repeat):
        t0 = time.perf_counter()
        fn()
        out.append(time.perf_counter() - t0)
    return out


def _reps_for(n: int) -> int:
    """Fewer repetitions at large n, where each run is expensive."""
    if n <= 12:
        return 200
    if n <= 18:
        return 40
    if n <= 21:
        return 10
    return 3


# --------------------------------------------------------------------------- #
# KPI 6 + 1: gate execution time and circuit execution time vs n
# --------------------------------------------------------------------------- #

def bench_gate_times() -> list[dict]:
    print("\n[1/5] Gate execution time vs qubit count")
    print("-" * 78)
    print(f"{'n':>3} {'dim':>12} {'MB':>9} {'H (ms)':>10} {'X (ms)':>10} "
          f"{'CNOT (ms)':>11} {'SWAP (ms)':>11}")

    rows = []
    for n in SWEEP:
        reps = _reps_for(n)
        state = QuantumState(n)
        gc.collect()

        t_h = _repeat(lambda: g.h(state, 0), reps)
        t_x = _repeat(lambda: g.x(state, 0), reps)
        if n >= 2:
            t_c = _repeat(lambda: g.cnot(state, 0, 1), reps)
            t_s = _repeat(lambda: g.swap(state, 0, 1), reps)
        else:
            t_c = t_s = [float("nan")]

        row = {
            "qubits": n,
            "dim": 2 ** n,
            "state_bytes": BYTES_PER_AMPLITUDE * 2 ** n,
            "h_ms": statistics.median(t_h) * 1e3,
            "x_ms": statistics.median(t_x) * 1e3,
            "cnot_ms": statistics.median(t_c) * 1e3,
            "swap_ms": statistics.median(t_s) * 1e3,
            "repeats": reps,
        }
        rows.append(row)
        print(f"{n:>3} {row['dim']:>12,} {row['state_bytes']/1e6:>9.3f} "
              f"{row['h_ms']:>10.4f} {row['x_ms']:>10.4f} "
              f"{row['cnot_ms']:>11.4f} {row['swap_ms']:>11.4f}")

        del state
        gc.collect()
    return rows


def bench_circuit_times() -> list[dict]:
    """Full GHZ-style circuit: H on q0 then a CNOT chain. 1 + (n-1) gates."""
    print("\n[2/5] Full circuit execution time (GHZ chain, n gates)")
    print("-" * 78)
    print(f"{'n':>3} {'gates':>6} {'total (ms)':>12} {'per gate (ms)':>15} "
          f"{'ms per M-amp':>14}")

    rows = []
    for n in SWEEP:
        reps = max(3, _reps_for(n) // 10)
        qc = Circuit(n).h(0)
        for q in range(n - 1):
            qc.cnot(q, q + 1)

        gc.collect()
        times = _repeat(lambda: qc.run(validate=False), reps)
        med = statistics.median(times)
        per_gate = med / qc.depth()
        per_mamp = med * 1e3 / (2 ** n / 1e6)

        rows.append({
            "qubits": n, "gates": qc.depth(),
            "total_ms": med * 1e3,
            "per_gate_ms": per_gate * 1e3,
            "ms_per_million_amplitudes": per_mamp,
        })
        print(f"{n:>3} {qc.depth():>6} {med*1e3:>12.4f} {per_gate*1e3:>15.5f} "
              f"{per_mamp:>14.4f}")
        gc.collect()
    return rows


# --------------------------------------------------------------------------- #
# KPI 2 + 5: memory usage and state vector size
# --------------------------------------------------------------------------- #

def bench_memory() -> list[dict]:
    print("\n[3/5] Memory usage: theoretical vs measured RSS")
    print("-" * 78)
    print(f"{'n':>3} {'amplitudes':>14} {'theory MB':>11} "
          f"{'RSS delta MB':>14} {'overhead %':>11}")

    proc = psutil.Process()
    rows = []
    for n in list(range(10, MAX_QUBITS_SWEEP + 1, 2)):
        gc.collect()
        before = proc.memory_info().rss
        state = QuantumState(n)
        # Touch the whole array so pages are actually resident.
        state.amplitudes[:] = 1.0 / np.sqrt(2 ** n)
        after = proc.memory_info().rss

        theory = BYTES_PER_AMPLITUDE * 2 ** n
        measured = after - before
        overhead = (measured - theory) / theory * 100 if theory else 0.0

        rows.append({
            "qubits": n, "amplitudes": 2 ** n,
            "theory_bytes": theory, "measured_rss_delta_bytes": measured,
            "overhead_pct": overhead,
        })
        print(f"{n:>3} {2**n:>14,} {theory/1e6:>11.3f} "
              f"{measured/1e6:>14.3f} {overhead:>11.1f}")

        del state
        gc.collect()
    return rows


def find_max_qubits(limit_fraction: float = 0.45) -> dict:
    """
    Empirically determine the largest register we can allocate and operate on,
    stopping before we risk the OOM killer. We require headroom for the
    temporary that gate application allocates, hence the conservative fraction.
    """
    print("\n[4/5] Maximum supported qubits on this machine")
    print("-" * 78)

    avail = psutil.virtual_memory().available
    budget = avail * limit_fraction
    print(f"  available RAM     : {avail/1e9:.2f} GB")
    print(f"  usable budget     : {budget/1e9:.2f} GB "
          f"({limit_fraction:.0%}, leaves room for gate temporaries)")

    max_n = 0
    for n in range(1, 40):
        need = BYTES_PER_AMPLITUDE * 2 ** n
        if need > budget:
            break
        max_n = n

    # Verify the predicted maximum actually runs a gate end to end.
    verified = 0
    try:
        gc.collect()
        st = QuantumState(max_n)
        t0 = time.perf_counter()
        g.h(st, 0)
        g.cnot(st, 0, 1)
        elapsed = time.perf_counter() - t0
        verified = max_n
        print(f"  predicted maximum : {max_n} qubits "
              f"({BYTES_PER_AMPLITUDE * 2**max_n / 1e9:.2f} GB)")
        print(f"  VERIFIED          : ran H + CNOT on {max_n} qubits "
              f"in {elapsed*1e3:.1f} ms")
        del st
        gc.collect()
    except MemoryError:
        print(f"  allocation of {max_n} qubits failed (MemoryError)")

    print("\n  Extrapolated memory requirement at larger scales:")
    for n in (30, 40, 45, 50, 60):
        b = BYTES_PER_AMPLITUDE * 2 ** n
        if b < 1e12:
            s = f"{b/1e9:,.1f} GB"
        elif b < 1e15:
            s = f"{b/1e12:,.1f} TB"
        elif b < 1e18:
            s = f"{b/1e15:,.1f} PB"
        else:
            s = f"{b/1e18:,.1f} EB"
        print(f"    {n:>3} qubits -> {2**n:>22,} amplitudes = {s:>12}")

    return {
        "available_ram_bytes": avail,
        "budget_fraction": limit_fraction,
        "max_qubits_predicted": max_n,
        "max_qubits_verified": verified,
    }


# --------------------------------------------------------------------------- #
# KPI 4: probability correctness
# --------------------------------------------------------------------------- #

def bench_correctness() -> dict:
    print("\n[5/5] Probability correctness")
    print("-" * 78)

    out: dict = {}

    # --- (a) analytic agreement on known circuits ---
    print("\n  (a) Exact probabilities vs hand-derived analytic values")
    cases = [
        ("H|0>  (coin)", Circuit(1).h(0), {"0": 0.5, "1": 0.5}),
        ("Bell  Phi+", Circuit(2).h(0).cnot(0, 1), {"00": 0.5, "11": 0.5}),
        ("GHZ-3", Circuit(3).h(0).cnot(0, 1).cnot(1, 2),
         {"000": 0.5, "111": 0.5}),
        ("uniform-3", Circuit(3).h(0).h(1).h(2),
         {format(k, "03b"): 0.125 for k in range(8)}),
        ("X|0>", Circuit(1).x(0), {"1": 1.0}),
    ]
    analytic = []
    print(f"    {'circuit':<16} {'max abs error':>15}")
    for name, qc, expected in cases:
        got = qc.run().probabilities
        err = max(abs(got.get(k, 0.0) - v) for k, v in expected.items())
        err = max(err, max((v for k, v in got.items()
                            if k not in expected), default=0.0))
        analytic.append({"circuit": name, "max_abs_error": err})
        print(f"    {name:<16} {err:>15.3e}")
    out["analytic"] = analytic

    # --- (b) norm preservation over deep random circuits ---
    print("\n  (b) Norm drift over deep random circuits (unitarity check)")
    rng = np.random.default_rng(2026)
    norm_rows = []
    print(f"    {'qubits':>7} {'gates':>7} {'|1 - norm|':>14}")
    for n, depth in ((4, 100), (6, 500), (8, 1000), (10, 2000), (12, 5000)):
        qc = Circuit(n)
        for _ in range(depth):
            kind = rng.integers(0, 4)
            if kind == 0:
                qc.h(int(rng.integers(0, n)))
            elif kind == 1:
                qc.x(int(rng.integers(0, n)))
            elif kind == 2:
                qc.z(int(rng.integers(0, n)))
            else:
                a, b = rng.choice(n, size=2, replace=False)
                qc.cnot(int(a), int(b))
        r = qc.run(validate=False)
        drift = abs(1.0 - r.state.norm())
        norm_rows.append({"qubits": n, "gates": depth, "norm_drift": drift})
        print(f"    {n:>7} {depth:>7} {drift:>14.3e}")
    out["norm_drift"] = norm_rows

    # --- (c) sampling convergence ---
    print("\n  (c) Sampled frequencies vs exact distribution (Bell state)")
    r = Circuit(2).h(0).cnot(0, 1).run()
    exact = r.probabilities
    conv = []
    print(f"    {'shots':>10} {'TVD':>10} {'1/sqrt(N)':>12}")
    for shots in (100, 1_000, 10_000, 100_000, 1_000_000):
        counts = sample(r.state, shots=shots, rng=rng)
        tvd = total_variation_distance(counts_to_frequencies(counts), exact)
        conv.append({"shots": shots, "tvd": tvd,
                     "one_over_sqrt_n": 1 / np.sqrt(shots)})
        print(f"    {shots:>10,} {tvd:>10.5f} {1/np.sqrt(shots):>12.5f}")
    out["sampling_convergence"] = conv

    # --- (d) float32 vs float64 precision comparison ---
    print("\n  (d) Precision: complex128 vs complex64 after 2000 gates")
    n, depth = 10, 2000
    qc = Circuit(n)
    rng2 = np.random.default_rng(7)
    for _ in range(depth):
        if rng2.integers(0, 2):
            qc.h(int(rng2.integers(0, n)))
        else:
            a, b = rng2.choice(n, size=2, replace=False)
            qc.cnot(int(a), int(b))

    r64 = qc.run(validate=False)
    ref = r64.state.amplitudes.copy()

    # Re-run the identical circuit in single precision.
    st32 = QuantumState(n)
    st32.amplitudes = st32.amplitudes.astype(np.complex64)
    for op in qc.operations:
        if op.name == "H":
            U = g.H.astype(np.complex64)
            psi = st32.amplitudes.reshape([2] * n)
            psi = np.tensordot(U, psi, axes=([1], [op.targets[0]]))
            psi = np.moveaxis(psi, 0, op.targets[0])
            st32.amplitudes = np.ascontiguousarray(psi).reshape(-1)
        else:
            c, t = op.targets
            psi = st32.amplitudes.reshape([2] * n)
            idx = [slice(None)] * n
            idx[c] = 1
            idx = tuple(idx)
            sub = psi[idx]
            t_sub = t - 1 if c < t else t
            U = g.X.astype(np.complex64)
            sub_new = np.tensordot(U, sub, axes=([1], [t_sub]))
            psi[idx] = np.moveaxis(sub_new, 0, t_sub)

    err32 = float(np.max(np.abs(st32.amplitudes.astype(np.complex128) - ref)))
    norm32 = float(abs(1.0 - np.sqrt(np.sum(np.abs(st32.amplitudes) ** 2))))
    norm64 = float(abs(1.0 - r64.state.norm()))
    print(f"    complex128 norm drift : {norm64:.3e}  "
          f"({ref.nbytes/1e6:.2f} MB)")
    print(f"    complex64  norm drift : {norm32:.3e}  "
          f"({st32.amplitudes.nbytes/1e6:.2f} MB)")
    print(f"    max amplitude deviation (64 vs 32): {err32:.3e}")
    out["precision"] = {
        "gates": depth, "qubits": n,
        "complex128_norm_drift": norm64,
        "complex64_norm_drift": norm32,
        "max_amplitude_deviation": err32,
        "complex128_bytes": int(ref.nbytes),
        "complex64_bytes": int(st32.amplitudes.nbytes),
    }
    return out


# --------------------------------------------------------------------------- #

def make_plots(gate_rows, circuit_rows, mem_rows) -> list[str]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(RESULTS_DIR, exist_ok=True)
    paths = []
    ns = [r["qubits"] for r in gate_rows]

    # --- Plot 1: gate time vs n (log y) ---
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.semilogy(ns, [r["h_ms"] for r in gate_rows], "o-", label="H (1-qubit)")
    ax.semilogy(ns, [r["x_ms"] for r in gate_rows], "s-", label="X (1-qubit)")
    ax.semilogy([r["qubits"] for r in gate_rows if r["qubits"] >= 2],
                [r["cnot_ms"] for r in gate_rows if r["qubits"] >= 2],
                "^-", label="CNOT (2-qubit)")
    ax.semilogy([r["qubits"] for r in gate_rows if r["qubits"] >= 2],
                [r["swap_ms"] for r in gate_rows if r["qubits"] >= 2],
                "d-", label="SWAP (2-qubit)")
    ax.set_xlabel("number of qubits (n)")
    ax.set_ylabel("median gate time (ms, log scale)")
    ax.set_title("Gate execution time scales as O(2^n)")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    p = os.path.join(RESULTS_DIR, "gate_time_scaling.png")
    fig.savefig(p, dpi=150)
    plt.close(fig)
    paths.append(p)

    # --- Plot 2: memory scaling ---
    fig, ax = plt.subplots(figsize=(8, 5))
    all_n = list(range(1, 51))
    ax.semilogy(all_n, [BYTES_PER_AMPLITUDE * 2 ** n / 1e9 for n in all_n],
                "-", color="crimson", label="theoretical 16 x 2^n")
    ax.semilogy([r["qubits"] for r in mem_rows],
                [r["measured_rss_delta_bytes"] / 1e9 for r in mem_rows],
                "o", color="navy", label="measured RSS delta")
    ax.axhline(psutil.virtual_memory().total / 1e9, ls="--", color="gray",
               label="this machine's RAM")
    ax.axhline(1e3, ls=":", color="darkorange", label="1 TB")
    ax.set_xlabel("number of qubits (n)")
    ax.set_ylabel("state vector memory (GB, log scale)")
    ax.set_title("State vector memory doubles with every added qubit")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    p = os.path.join(RESULTS_DIR, "memory_scaling.png")
    fig.savefig(p, dpi=150)
    plt.close(fig)
    paths.append(p)

    # --- Plot 3: circuit time + throughput ---
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    ax1.semilogy([r["qubits"] for r in circuit_rows],
                 [r["total_ms"] for r in circuit_rows], "o-", color="darkgreen")
    ax1.set_xlabel("number of qubits (n)")
    ax1.set_ylabel("circuit time (ms, log)")
    ax1.set_title("GHZ circuit total time")
    ax1.grid(True, which="both", alpha=0.3)

    ax2.plot([r["qubits"] for r in circuit_rows],
             [r["ms_per_million_amplitudes"] for r in circuit_rows],
             "o-", color="purple")
    ax2.set_xlabel("number of qubits (n)")
    ax2.set_ylabel("ms per million amplitudes")
    ax2.set_title("Normalised cost: overhead-bound (left) vs memory-bound (right)")
    ax2.set_yscale("log")
    ax2.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    p = os.path.join(RESULTS_DIR, "circuit_time_scaling.png")
    fig.savefig(p, dpi=150)
    plt.close(fig)
    paths.append(p)

    return paths


def main() -> None:
    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("=" * 78)
    print("QUANTUM SIMULATOR — KPI BENCHMARK")
    print("=" * 78)
    env = {
        "python": sys.version.split()[0],
        "numpy": np.__version__,
        "platform": platform.platform(),
        "processor": platform.processor() or "unknown",
        "cpu_count": os.cpu_count(),
        "total_ram_bytes": psutil.virtual_memory().total,
        "dtype": "complex128 (16 bytes/amplitude)",
    }
    print(f"  python {env['python']} | numpy {env['numpy']} | "
          f"{env['cpu_count']} CPU | "
          f"{env['total_ram_bytes']/1e9:.1f} GB RAM")
    print(f"  {env['platform']}")

    gate_rows = bench_gate_times()
    circuit_rows = bench_circuit_times()
    mem_rows = bench_memory()
    max_info = find_max_qubits()
    correctness = bench_correctness()

    print("\n" + "=" * 78)
    print("Generating plots...")
    plots = make_plots(gate_rows, circuit_rows, mem_rows)
    for p in plots:
        print(f"  wrote {os.path.relpath(p)}")

    payload = {
        "environment": env,
        "gate_times": gate_rows,
        "circuit_times": circuit_rows,
        "memory": mem_rows,
        "max_qubits": max_info,
        "correctness": correctness,
    }
    out_path = os.path.join(RESULTS_DIR, "kpi_results.json")
    with open(out_path, "w") as f:
        json.dump(payload, f, indent=2)
    print(f"  wrote {os.path.relpath(out_path)}")

    # --- doubling-ratio summary, the headline scaling evidence ---
    print("\n" + "=" * 78)
    print("SCALING SUMMARY — time ratio per added qubit (should approach 2.0)")
    print("-" * 78)
    print(f"{'n':>3} {'H time (ms)':>13} {'ratio vs n-1':>14}")
    for i, r in enumerate(gate_rows):
        if i == 0:
            print(f"{r['qubits']:>3} {r['h_ms']:>13.5f} {'-':>14}")
        else:
            ratio = r["h_ms"] / gate_rows[i - 1]["h_ms"]
            print(f"{r['qubits']:>3} {r['h_ms']:>13.5f} {ratio:>14.2f}")
    print("=" * 78)
    print("Done.")


if __name__ == "__main__":
    main()
