"""
test_simulator.py — Correctness tests.

Each test checks the simulator against a result derived analytically by hand,
rather than against another simulator. Run with:  python -m pytest -q
(or just `python tests/test_simulator.py` for a plain-stdlib run).
"""

import sys
import os

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from quantum_sim import (  # noqa: E402
    Circuit, QuantumState, X, Y, Z, H, S, T, I,
    is_unitary, sample, measure_qubit, counts_to_frequencies,
    total_variation_distance,
)
import quantum_sim.gates as g  # noqa: E402

SQRT1_2 = 1 / np.sqrt(2)


# --------------------------------------------------------------------------- #
# Gate matrix properties
# --------------------------------------------------------------------------- #

def test_all_gates_unitary():
    for name, U in g.SINGLE_QUBIT_GATES.items():
        assert is_unitary(U), f"{name} is not unitary"


def test_pauli_involutions():
    # X, Y, Z are their own inverses: U^2 = I
    for U in (X, Y, Z):
        assert np.allclose(U @ U, I)
    # H is also an involution
    assert np.allclose(H @ H, I)


def test_s_squared_is_z():
    assert np.allclose(S @ S, Z)


def test_t_fourth_is_z():
    assert np.allclose(np.linalg.matrix_power(T, 4), Z)


# --------------------------------------------------------------------------- #
# Single-qubit behaviour
# --------------------------------------------------------------------------- #

def test_x_flips_basis_state():
    r = Circuit(1).x(0).run()
    assert np.allclose(r.state.amplitudes, [0, 1])


def test_x_twice_is_identity():
    r = Circuit(1).x(0).x(0).run()
    assert np.allclose(r.state.amplitudes, [1, 0])


def test_hadamard_creates_equal_superposition():
    r = Circuit(1).h(0).run()
    probs = r.state.probabilities()
    assert np.allclose(probs, [0.5, 0.5]), probs
    assert np.allclose(r.state.amplitudes, [SQRT1_2, SQRT1_2])


def test_hadamard_self_inverse():
    """H|0> is a superposition, but H H |0> must return exactly to |0>."""
    r = Circuit(1).h(0).h(0).run()
    assert np.allclose(r.state.amplitudes, [1, 0])


def test_z_leaves_probabilities_but_flips_phase():
    r = Circuit(1).h(0).z(0).run()
    # Probabilities unchanged...
    assert np.allclose(r.state.probabilities(), [0.5, 0.5])
    # ...but the |1> amplitude picked up a minus sign.
    assert np.allclose(r.state.amplitudes, [SQRT1_2, -SQRT1_2])


def test_hzh_equals_x():
    """H Z H == X. Demonstrates phase becoming observable via interference."""
    r1 = Circuit(1).h(0).z(0).h(0).run()
    r2 = Circuit(1).x(0).run()
    assert np.allclose(r1.state.amplitudes, r2.state.amplitudes)


# --------------------------------------------------------------------------- #
# Multi-qubit and entanglement
# --------------------------------------------------------------------------- #

def test_bell_state_amplitudes():
    """H(q0) then CNOT(q0->q1) gives (|00> + |11>)/sqrt(2)."""
    r = Circuit(2).h(0).cnot(0, 1).run()
    expected = np.array([SQRT1_2, 0, 0, SQRT1_2])
    assert np.allclose(r.state.amplitudes, expected), r.state.amplitudes


def test_bell_state_probabilities():
    r = Circuit(2).h(0).cnot(0, 1).run()
    p = r.probabilities
    assert set(p) == {"00", "11"}
    assert abs(p["00"] - 0.5) < 1e-12
    assert abs(p["11"] - 0.5) < 1e-12


def test_all_four_bell_states():
    """The four maximally entangled Bell states, each built and checked."""
    # Phi+ = (|00> + |11>)/sqrt2
    r = Circuit(2).h(0).cnot(0, 1).run()
    assert np.allclose(r.state.amplitudes, [SQRT1_2, 0, 0, SQRT1_2])

    # Phi- = (|00> - |11>)/sqrt2
    r = Circuit(2).h(0).cnot(0, 1).z(0).run()
    assert np.allclose(r.state.amplitudes, [SQRT1_2, 0, 0, -SQRT1_2])

    # Psi+ = (|01> + |10>)/sqrt2
    r = Circuit(2).h(0).cnot(0, 1).x(1).run()
    assert np.allclose(r.state.amplitudes, [0, SQRT1_2, SQRT1_2, 0])

    # Psi- = (|01> - |10>)/sqrt2
    r = Circuit(2).h(0).cnot(0, 1).z(0).x(1).run()
    assert np.allclose(r.state.amplitudes, [0, SQRT1_2, -SQRT1_2, 0])


def test_cnot_truth_table():
    """CNOT on basis states behaves as the classical controlled-NOT."""
    table = {0b00: 0b00, 0b01: 0b01, 0b10: 0b11, 0b11: 0b10}
    for src, dst in table.items():
        st = QuantumState.from_basis_state(2, src)
        r = Circuit(2).cnot(0, 1).run(initial_state=st)
        expected = np.zeros(4)
        expected[dst] = 1
        assert np.allclose(r.state.amplitudes, expected), (src, dst)


def test_cnot_does_nothing_when_control_is_zero():
    st = QuantumState.from_basis_state(2, 0b01)
    r = Circuit(2).cnot(0, 1).run(initial_state=st)
    assert np.allclose(r.state.amplitudes, [0, 1, 0, 0])


def test_cnot_reversed_control_target():
    """CNOT(1 -> 0) must flip qubit 0 when qubit 1 is set."""
    st = QuantumState.from_basis_state(2, 0b01)  # q0=0, q1=1
    r = Circuit(2).cnot(1, 0).run(initial_state=st)
    assert np.allclose(r.state.amplitudes, [0, 0, 0, 1])  # -> |11>


def test_swap_gate():
    st = QuantumState.from_basis_state(2, 0b10)  # |10>
    r = Circuit(2).swap(0, 1).run(initial_state=st)
    assert np.allclose(r.state.amplitudes, [0, 1, 0, 0])  # -> |01>


def test_swap_equals_three_cnots():
    """Standard identity: SWAP == CNOT(a,b) CNOT(b,a) CNOT(a,b)."""
    for init in range(4):
        st = QuantumState.from_basis_state(2, init)
        r1 = Circuit(2).swap(0, 1).run(initial_state=st)
        r2 = Circuit(2).cnot(0, 1).cnot(1, 0).cnot(0, 1).run(initial_state=st)
        assert np.allclose(r1.state.amplitudes, r2.state.amplitudes), init


def test_ghz_three_qubit():
    """GHZ state: (|000> + |111>)/sqrt(2)."""
    r = Circuit(3).h(0).cnot(0, 1).cnot(1, 2).run()
    expected = np.zeros(8)
    expected[0b000] = SQRT1_2
    expected[0b111] = SQRT1_2
    assert np.allclose(r.state.amplitudes, expected)


def test_three_qubit_uniform_superposition():
    """H on every qubit gives all 8 outcomes at probability 1/8."""
    r = Circuit(3).h(0).h(1).h(2).run()
    assert np.allclose(r.state.probabilities(), np.full(8, 1 / 8))


def test_gate_on_middle_qubit_only():
    """Axis bookkeeping check: X on q1 of a 3-qubit register."""
    r = Circuit(3).x(1).run()
    expected = np.zeros(8)
    expected[0b010] = 1
    assert np.allclose(r.state.amplitudes, expected)


# --------------------------------------------------------------------------- #
# Normalisation
# --------------------------------------------------------------------------- #

def test_norm_preserved_through_random_circuit():
    rng = np.random.default_rng(1234)
    n = 4
    qc = Circuit(n)
    for _ in range(60):
        kind = rng.integers(0, 4)
        if kind == 0:
            qc.h(int(rng.integers(0, n)))
        elif kind == 1:
            qc.x(int(rng.integers(0, n)))
        elif kind == 2:
            qc.z(int(rng.integers(0, n)))
        else:
            a, b = rng.choice(n, size=2, replace=False)
            qc.cnot(int(a), int(b))
    r = qc.run(validate=True)
    assert abs(r.state.norm() - 1.0) < 1e-12, r.state.norm()


def test_probabilities_sum_to_one():
    r = Circuit(3).h(0).cnot(0, 1).h(2).run()
    assert abs(r.state.probabilities().sum() - 1.0) < 1e-12


# --------------------------------------------------------------------------- #
# Measurement
# --------------------------------------------------------------------------- #

def test_sampling_matches_analytic_distribution():
    """Sampled frequencies should converge to the exact Bell distribution."""
    r = Circuit(2).h(0).cnot(0, 1).run()
    rng = np.random.default_rng(42)
    counts = sample(r.state, shots=200_000, rng=rng)
    freqs = counts_to_frequencies(counts)
    tvd = total_variation_distance(freqs, r.probabilities)
    assert tvd < 0.01, (freqs, tvd)
    # |01> and |10> must never appear in a Bell state.
    assert "01" not in counts and "10" not in counts


def test_measurement_collapse_is_correlated():
    """
    In a Bell state, measuring q0 must force q1 to the same value. Repeat many
    times to confirm the correlation is perfect, not merely likely.
    """
    rng = np.random.default_rng(7)
    for _ in range(300):
        r = Circuit(2).h(0).cnot(0, 1).run()
        b0 = measure_qubit(r.state, 0, rng=rng)
        b1 = measure_qubit(r.state, 1, rng=rng)
        assert b0 == b1, (b0, b1)


def test_collapsed_state_is_normalised():
    rng = np.random.default_rng(3)
    r = Circuit(3).h(0).h(1).h(2).run()
    measure_qubit(r.state, 1, rng=rng)
    assert abs(r.state.norm() - 1.0) < 1e-12


def test_measuring_deterministic_state_is_deterministic():
    r = Circuit(2).x(0).run()  # |10>, no superposition
    rng = np.random.default_rng(0)
    for _ in range(50):
        st = r.state.copy()
        assert measure_qubit(st, 0, rng=rng) == 1


def test_coin_toss_is_fair():
    """Quantum coin toss: a single H should give ~50/50 over many shots."""
    r = Circuit(1).h(0).run()
    rng = np.random.default_rng(99)
    counts = sample(r.state, shots=100_000, rng=rng)
    frac = counts["0"] / 100_000
    assert abs(frac - 0.5) < 0.01, frac


# --------------------------------------------------------------------------- #
# Error handling
# --------------------------------------------------------------------------- #

def test_rejects_non_unitary_custom_gate():
    bad = np.array([[1, 1], [0, 1]], dtype=complex)  # shear, not unitary
    try:
        Circuit(1).custom("BAD", bad, 0)
    except ValueError:
        return
    raise AssertionError("non-unitary gate was accepted")


def test_rejects_out_of_range_qubit():
    try:
        Circuit(2).h(5)
    except ValueError:
        return
    raise AssertionError("out-of-range qubit was accepted")


def test_rejects_cnot_with_same_control_and_target():
    try:
        Circuit(2).cnot(1, 1)
    except ValueError:
        return
    raise AssertionError("CNOT with control == target was accepted")


def test_rejects_unnormalised_state():
    try:
        QuantumState(1, np.array([1.0, 1.0], dtype=complex))
    except ValueError:
        return
    raise AssertionError("unnormalised state was accepted")


# --------------------------------------------------------------------------- #

def _main():
    tests = [(n, o) for n, o in sorted(globals().items())
             if n.startswith("test_") and callable(o)]
    passed = 0
    for name, fn in tests:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"FAIL  {name}: {exc}")
        else:
            passed += 1
            print(f"ok    {name}")
    print(f"\n{passed}/{len(tests)} tests passed")
    return 0 if passed == len(tests) else 1


if __name__ == "__main__":
    raise SystemExit(_main())
