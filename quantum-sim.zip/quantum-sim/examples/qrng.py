"""
qrng.py — Quantum random number generator.

Put n qubits into a uniform superposition with one Hadamard each, then measure.
The register collapses to one of 2^n bitstrings, each with probability 2^-n, so
a 3-qubit register yields a uniform integer in [0, 7].

Honest caveat, which matters for the report: this is a *simulation* of a QRNG.
The randomness actually comes from NumPy's PRNG sampling our computed
distribution, so it is no more physically random than any classical PRNG. On
real hardware the collapse itself supplies the entropy. What the simulator does
demonstrate correctly is the circuit construction and the resulting uniform
distribution.

Run:  python examples/qrng.py
"""

import os
import sys
from collections import Counter

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from quantum_sim import Circuit, sample, counts_to_frequencies  # noqa: E402

N_QUBITS = 3
SHOTS = 50_000


def uniform_circuit(n: int) -> Circuit:
    """H on every qubit -> uniform superposition over all 2^n basis states."""
    qc = Circuit(n)
    for q in range(n):
        qc.h(q)
    return qc


def chi_square_uniformity(counts: dict[str, int], n_outcomes: int) -> float:
    """
    Pearson chi-square statistic against a uniform distribution.
    For a fair generator this should land near its expected value,
    df = n_outcomes - 1.
    """
    total = sum(counts.values())
    expected = total / n_outcomes
    observed = [counts.get(format(k, f"0{int(np.log2(n_outcomes))}b"), 0)
                for k in range(n_outcomes)]
    return sum((o - expected) ** 2 / expected for o in observed)


def main() -> None:
    rng = np.random.default_rng(2026)

    print("=" * 68)
    print(f"QUANTUM RANDOM NUMBER GENERATOR ({N_QUBITS} qubits)")
    print("=" * 68)

    qc = uniform_circuit(N_QUBITS)
    print("\nCircuit:")
    print(qc.diagram())

    result = qc.run()
    dim = 2 ** N_QUBITS
    print(f"\nstate vector : {dim} amplitudes "
          f"({result.state.nbytes()} bytes)")
    print(f"every amplitude = 1/sqrt({dim}) = {1/np.sqrt(dim):.6f}")
    print(f"every probability = 1/{dim} = {1/dim:.6f}")

    # ---- distribution over shots ----
    counts = sample(result.state, shots=SHOTS, rng=rng)
    freqs = counts_to_frequencies(counts)
    print(f"\nSampled distribution ({SHOTS:,} shots)")
    print("-" * 68)
    print(f"  {'value':>5}  {'bits':>6}  {'count':>7}  {'freq':>8}  "
          f"{'error':>8}")
    for k in range(dim):
        bits = format(k, f"0{N_QUBITS}b")
        c = counts.get(bits, 0)
        f = freqs.get(bits, 0.0)
        print(f"  {k:>5}  {bits:>6}  {c:>7,d}  {f:>8.5f}  "
              f"{abs(f - 1/dim):>8.5f}")

    chi2 = chi_square_uniformity(counts, dim)
    print(f"\n  chi-square = {chi2:.3f}  (df = {dim - 1}, "
          f"expected ~ {dim - 1})")

    # ---- generate actual random integers ----
    print(f"\nGenerating 20 random integers in [0, {dim - 1}]")
    print("-" * 68)
    draws = []
    for _ in range(20):
        st = qc.run(validate=False).state
        bits = list(sample(st, shots=1, rng=rng).keys())[0]
        draws.append(int(bits, 2))
    print("  " + "  ".join(f"{d}" for d in draws))

    # ---- scaling to a wider register ----
    print("\nScaling the register width")
    print("-" * 68)
    print(f"  {'qubits':>7}  {'outcomes':>10}  {'state bytes':>12}  "
          f"{'build time':>11}")
    for n in (1, 2, 4, 8, 12, 16):
        qcn = uniform_circuit(n)
        rn = qcn.run(validate=False)
        print(f"  {n:>7}  {2**n:>10,}  {rn.state.nbytes():>12,}  "
              f"{rn.total_time_s * 1e3:>10.3f}ms")

    print("\n  Note the outcome count and memory both double per qubit added.")

    exact = result.state.probabilities()
    assert np.allclose(exact, 1 / dim), "distribution is not uniform"
    print(f"\n[PASS] all {dim} outcomes are exactly equiprobable.")


if __name__ == "__main__":
    main()
