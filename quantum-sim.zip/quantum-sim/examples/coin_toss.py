"""
coin_toss.py — The simplest possible quantum circuit: a single Hadamard.

A classical coin is random only because we lack information about it. A qubit
in H|0> = (|0> + |1>)/sqrt(2) is random in a stronger sense: the state is
completely specified, and the outcome is still not determined until measured.

This example also shows the *biased* coin, obtained by using a rotation other
than H, to make the point that the amplitudes — not some external probability
parameter — are what set the odds.

Run:  python examples/coin_toss.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from quantum_sim import Circuit, sample, counts_to_frequencies  # noqa: E402

SHOTS = 20_000


def ry(theta: float) -> np.ndarray:
    """Rotation about Y — gives a biased coin with P(1) = sin^2(theta/2)."""
    c, s = np.cos(theta / 2), np.sin(theta / 2)
    return np.array([[c, -s], [s, c]], dtype=complex)


def main() -> None:
    rng = np.random.default_rng(2026)

    print("=" * 68)
    print("QUANTUM COIN TOSS")
    print("=" * 68)

    qc = Circuit(1).h(0)
    print("\nCircuit:")
    print(qc.diagram())

    result = qc.run()
    print(f"\nstate       : {result.state.to_ket()}")
    print(f"probabilities: {result.probabilities}")

    counts = sample(result.state, shots=SHOTS, rng=rng)
    freqs = counts_to_frequencies(counts)
    print(f"\nFair coin — {SHOTS:,} shots")
    print("-" * 68)
    for k in ("0", "1"):
        c, f = counts.get(k, 0), freqs.get(k, 0.0)
        print(f"  |{k}>  {c:6,d}  ({f:.4f})  {'#' * int(round(f * 50))}")
    print(f"\n  deviation from 0.5: {abs(freqs['0'] - 0.5):.5f}")

    # ---- convergence with shot count ----
    print("\nConvergence of the estimate (statistical error ~ 1/sqrt(N))")
    print("-" * 68)
    print(f"  {'shots':>9}  {'P(0) est':>9}  {'|error|':>9}  {'1/sqrt(N)':>10}")
    for n_shots in (10, 100, 1_000, 10_000, 100_000, 1_000_000):
        c = sample(result.state, shots=n_shots, rng=rng)
        est = c.get("0", 0) / n_shots
        print(f"  {n_shots:>9,}  {est:>9.5f}  {abs(est - 0.5):>9.5f}"
              f"  {1/np.sqrt(n_shots):>10.5f}")

    # ---- biased coin ----
    print("\nBiased coin via Ry(theta): P(1) = sin^2(theta/2)")
    print("-" * 68)
    print(f"  {'theta':>8}  {'P(1) exact':>11}  {'P(1) sampled':>13}")
    for theta in (np.pi / 6, np.pi / 4, np.pi / 3, np.pi / 2, 2 * np.pi / 3):
        qcb = Circuit(1).custom("Ry", ry(theta), 0)
        rb = qcb.run()
        exact = rb.state.probabilities()[1]
        cb = sample(rb.state, shots=SHOTS, rng=rng)
        est = cb.get("1", 0) / SHOTS
        print(f"  {theta:>8.4f}  {exact:>11.5f}  {est:>13.5f}")

    # ---- multi-coin ----
    print("\nThree independent coins (H on every qubit)")
    print("-" * 68)
    r3 = Circuit(3).h(0).h(1).h(2).run()
    c3 = sample(r3.state, shots=SHOTS, rng=rng)
    f3 = counts_to_frequencies(c3)
    for k in sorted(c3):
        print(f"  |{k}>  {c3[k]:6,d}  ({f3[k]:.4f})  "
              f"{'#' * int(round(f3[k] * 200))}")
    print(f"\n  each should sit near 1/8 = {1/8:.4f}")

    assert abs(result.probabilities["0"] - 0.5) < 1e-12
    print("\n[PASS] fair coin gives exactly 50/50 in the analytic distribution.")


if __name__ == "__main__":
    main()
