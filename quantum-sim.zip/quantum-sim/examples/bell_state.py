"""
bell_state.py — The flagship example circuit: generating an entangled pair.

Workflow (exactly as in the task hint):
    1. Apply H to qubit 0        -> (|00> + |10>)/sqrt(2)
    2. Apply CNOT(q0 -> q1)      -> (|00> + |11>)/sqrt(2)
    3. Measure probabilities     -> 50% |00>, 50% |11>

The interesting part is what is NOT in the output: |01> and |10> have exactly
zero amplitude. The two qubits are individually random but perfectly
correlated, which is the signature of entanglement. We demonstrate that
directly by measuring qubit 0 and showing qubit 1 is then forced to match.

Run:  python examples/bell_state.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from quantum_sim import (  # noqa: E402
    Circuit, sample, measure_qubit, counts_to_frequencies,
    total_variation_distance,
)

SHOTS = 10_000


def main() -> None:
    print("=" * 68)
    print("BELL STATE GENERATION  |Phi+> = (|00> + |11>) / sqrt(2)")
    print("=" * 68)

    qc = Circuit(2).h(0).cnot(0, 1)

    print("\nCircuit:")
    print(qc.diagram())
    print(f"\ngates: {qc.depth()}    "
          f"state vector: 2^2 = 4 amplitudes "
          f"({qc.state_vector_bytes()} bytes)")

    # ---- step through the circuit so the intermediate state is visible ----
    print("\nStep-by-step evolution")
    print("-" * 68)
    step0 = Circuit(2).run()
    print(f"  initial            : {step0.state.to_ket()}")
    step1 = Circuit(2).h(0).run()
    print(f"  after H(q0)        : {step1.state.to_ket()}")
    result = qc.run()
    print(f"  after CNOT(q0->q1) : {result.state.to_ket()}")

    # ---- exact probabilities ----
    print("\nExact probabilities (from |amplitude|^2)")
    print("-" * 68)
    exact = result.probabilities
    for k in sorted(["00", "01", "10", "11"]):
        p = exact.get(k, 0.0)
        bar = "#" * int(round(p * 50))
        print(f"  |{k}>  {p:7.4f}  {bar}")
    print("\n  Note |01> and |10> are exactly zero — the qubits can never "
          "disagree.")

    # ---- sampled measurement ----
    print(f"\nSampled measurement ({SHOTS:,} shots)")
    print("-" * 68)
    rng = np.random.default_rng(2026)
    counts = sample(result.state, shots=SHOTS, rng=rng)
    freqs = counts_to_frequencies(counts)
    for k, c in sorted(counts.items()):
        bar = "#" * int(round(freqs[k] * 50))
        print(f"  |{k}>  {c:6,d}  ({freqs[k]:.4f})  {bar}")

    tvd = total_variation_distance(freqs, exact)
    print(f"\n  total variation distance from exact: {tvd:.5f}")
    print(f"  (expected O(1/sqrt(shots)) ~ {1/np.sqrt(SHOTS):.5f})")

    # ---- entanglement demonstration ----
    print("\nEntanglement check: measure q0, then read q1")
    print("-" * 68)
    agree = 0
    trials = 1000
    for _ in range(trials):
        st = qc.run(validate=False).state
        b0 = measure_qubit(st, 0, rng=rng)
        b1 = measure_qubit(st, 1, rng=rng)
        agree += (b0 == b1)
    print(f"  qubits agreed in {agree}/{trials} trials "
          f"({100 * agree / trials:.1f}%)")
    print("  Measuring q0 collapses the shared state, so q1 is determined "
          "instantly.")

    # ---- timing ----
    print("\nTiming")
    print("-" * 68)
    print(f"  total circuit time : {result.total_time_s * 1e6:8.2f} us")
    for name, t in zip(result.gate_names, result.gate_times_s):
        print(f"  {name:<6}            : {t * 1e6:8.2f} us")

    # ---- correctness assertion ----
    assert abs(exact["00"] - 0.5) < 1e-12
    assert abs(exact["11"] - 0.5) < 1e-12
    assert "01" not in exact and "10" not in exact
    print("\n[PASS] output matches the analytic Bell state exactly.")


if __name__ == "__main__":
    main()
