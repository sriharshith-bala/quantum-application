# Technical Report — Hybrid Quantum Circuit Simulation

**Phoenix Association — IT Team Induction 2026–27**

---

## 1. Introduction and Objective

The goal was to build a small quantum circuit simulator from first principles —
representing qubits, applying gates, simulating measurement — and then to
analyse its computational complexity, memory behaviour, and feasibility on
FPGA or embedded hardware.

The emphasis throughout is on understanding rather than scale. The simulator is
deliberately small and readable: roughly 600 lines of commented Python across
four modules, with no quantum library anywhere in the dependency chain. NumPy is
used for array arithmetic only; every gate is an explicit matrix that the code
constructs and applies itself.

**Environment for all measurements in this report:** Python 3.12.3, NumPy 2.4.4,
Linux x86-64, 1 CPU core, 4.19 GB RAM.

---

## 2. Quantum State Representation

### 2.1 How qubits are stored

An *n*-qubit register is stored as a single dense **state vector**: a flat 1-D
NumPy array of 2ⁿ complex amplitudes.

```
|ψ⟩ = Σ(k=0 to 2ⁿ-1) c_k |k⟩
```

where *k* is the integer whose binary expansion names the basis state. The array
holds `[c₀, c₁, …, c_{2ⁿ-1}]` and nothing else — there is no per-qubit object,
no gate history, no metadata.

We adopt the convention that **qubit 0 is the most significant bit**, so for a
3-qubit register |q₀q₁q₂⟩ = |101⟩ sits at index 5. This matches the ordering
used in the task sheet's Bell state description.

The dtype is `complex128` — two IEEE-754 float64s, so **16 bytes per
amplitude**. This single choice determines the entire memory story of the
project, and §5.4 examines what happens if it is relaxed.

```python
class QuantumState:
    def __init__(self, num_qubits):
        self.dim = 2 ** num_qubits
        self.amplitudes = np.zeros(self.dim, dtype=np.complex128)
        self.amplitudes[0] = 1.0        # initial state |00...0⟩
```

Why one flat array rather than, say, a list of qubit objects? Because qubits in
an entangled state have **no individual descriptions**. A Bell pair is not "two
qubits each in some state"; it is one joint state that cannot be factored. Any
representation that stores per-qubit data would be unable to express
entanglement at all. The 2ⁿ vector is the smallest structure that can.

### 2.2 How superposition is represented

Superposition requires no special machinery — it is simply the condition that
**more than one amplitude is non-zero**. There is no `is_superposed` flag
anywhere in the code, because there does not need to be.

A single qubit after a Hadamard:

```
H|0⟩ = (1/√2)|0⟩ + (1/√2)|1⟩   →   amplitudes = [0.7071, 0.7071]
```

Both entries are non-zero, so the qubit is in superposition. The measured output
from `examples/bell_state.py` shows this transition directly:

```
initial            : 1.0000|00>
after H(q0)        : 0.7071|00> + 0.7071|10>
after CNOT(q0->q1) : 0.7071|00> + 0.7071|11>
```

Entanglement is likewise implicit. The final state above cannot be written as a
tensor product of two single-qubit states, and the code never needs to detect
this — operating on the full 2ⁿ vector handles entangled and separable states
through exactly the same path.

### 2.3 How probabilities are computed

By the **Born rule**: the probability of observing basis state *k* is the
squared magnitude of its amplitude.

```
P(k) = |c_k|² = Re(c_k)² + Im(c_k)²
```

```python
def probabilities(self):
    return np.abs(self.amplitudes) ** 2
```

Normalisation requires Σ|c_k|² = 1, which every unitary gate preserves. We use
this as a **built-in correctness check**: `Circuit.run(validate=True)` re-checks
the norm after every gate, so a buggy gate implementation surfaces immediately
as norm drift rather than silently producing wrong answers. (The benchmarks
disable this, since the check is itself an O(2ⁿ) pass.)

For a single qubit's marginal probability we sum over all other axes:

```python
probs = self.probabilities().reshape([2] * n)
axes = tuple(a for a in range(n) if a != qubit)
marginal = probs.sum(axis=axes)
```

---

## 3. Quantum Gate Implementation

### 3.1 Gate matrices

All mandatory and optional gates are implemented, plus extras:

| Gate | Matrix | Effect |
|---|---|---|
| **X** (Pauli-X) | `[[0,1],[1,0]]` | Quantum NOT — swaps \|0⟩ and \|1⟩ amplitudes |
| **H** (Hadamard) | `(1/√2)[[1,1],[1,-1]]` | Creates equal superposition |
| **CNOT** | controlled-X | Flips target iff control is \|1⟩ — **creates entanglement** |
| **Z** (Pauli-Z) | `[[1,0],[0,-1]]` | Phase flip on \|1⟩ |
| **SWAP** | axis exchange | Exchanges two qubits |
| Y, S, T, CZ | — | Included for completeness |

Every matrix is validated as unitary (U†U = I) on construction; a non-unitary
matrix is rejected, since it would break normalisation and produce meaningless
probabilities.

### 3.2 The central engineering decision: avoiding the full operator

This is the most important implementation choice in the project, and the thing
most worth understanding.

Formally, a gate acting on one qubit of an *n*-qubit register is a 2ⁿ × 2ⁿ
matrix built by tensoring the 2×2 gate with identities:

```
U_full = I ⊗ I ⊗ … ⊗ U ⊗ … ⊗ I
```

Applying it naively as a matrix-vector product costs **O(4ⁿ) time** and, worse,
**O(4ⁿ) memory just to store the operator**. At 20 qubits that operator would be
17.6 TB. This approach is unusable beyond about 12 qubits.

We never build it. Instead, we exploit the fact that the gate is the identity on
every other qubit. Reshaping the flat 2ⁿ vector into an *n*-dimensional tensor of
shape (2, 2, …, 2) gives **each qubit its own axis**, and the gate becomes a
contraction against just that one axis:

```python
psi = amplitudes.reshape([2] * n)                  # each qubit = one axis
psi = np.tensordot(U, psi, axes=([1], [target]))   # contract over target
psi = np.moveaxis(psi, 0, target)                  # restore axis order
```

This costs **O(2ⁿ) time** and allocates only O(2ⁿ) scratch — an exponential
saving. The comparison at 20 qubits:

| Approach | Operator storage | Time per gate |
|---|---|---|
| Full 2ⁿ × 2ⁿ matrix | 17.6 TB | O(4ⁿ) ≈ 10¹² ops |
| Axis contraction (ours) | 32 bytes (the 2×2) | O(2ⁿ) ≈ 10⁶ ops |

### 3.3 Controlled gates and how entanglement arises

A CNOT is handled the same way, except we first slice out the half of the tensor
where the control qubit is |1⟩ and apply the 2×2 matrix only to that sub-block:

```python
idx = [slice(None)] * n
idx[control] = 1
sub = psi[tuple(idx)]            # NumPy basic slicing → a VIEW, not a copy

t_sub = target - 1 if control < target else target   # control axis removed
sub_new = np.tensordot(U, sub, axes=([1], [t_sub]))
psi[tuple(idx)] = np.moveaxis(sub_new, 0, t_sub)     # in-place write-back
```

Two details matter here. First, because basic slicing returns a **view**, the
write-back mutates the original buffer directly — the control-|0⟩ half is never
copied or touched. Second, removing the control axis shifts every subsequent
axis down by one, which is the `t_sub` adjustment. Getting this wrong is a
silent correctness bug, which is why the test suite includes
`test_cnot_reversed_control_target` and `test_gate_on_middle_qubit_only`
specifically to catch axis-bookkeeping errors.

**This is where entanglement comes from.** Because the operation applied to the
target *depends on the value of the control*, the resulting state can no longer
be factored into independent single-qubit states. Applying CNOT to a
superposition of control values entangles the two:

```
(|0⟩+|1⟩)/√2 ⊗ |0⟩  --CNOT-->  (|00⟩+|11⟩)/√2
```

The left side is a product state; the right side is not.

**SWAP** is implemented directly as `np.swapaxes` on the reshaped tensor rather
than as three CNOTs — one pass instead of three. The test suite verifies the two
are equivalent (`test_swap_equals_three_cnots`), and the benchmark shows SWAP is
consistently the cheapest two-qubit operation as a result.

---

## 4. Circuit Execution

### 4.1 Design

`Circuit` is a pure **description** — an ordered list of operations holding no
state vector. `run()` allocates a fresh state and applies each operation in
sequence. This separation means the same circuit can be executed repeatedly for
shot statistics or benchmarking without being rebuilt, and it makes per-gate
timing instrumentation natural.

```python
qc = Circuit(2).h(0).cnot(0, 1)     # methods chain
result = qc.run()
```

### 4.2 Bell state — the complete worked example

The mandatory workflow, with verified output from `examples/bell_state.py`:

```
Circuit:
q0: [ H  ]--●---
q1: --------⊕---

Step-by-step evolution
  initial            : 1.0000|00>
  after H(q0)        : 0.7071|00> + 0.7071|10>
  after CNOT(q0->q1) : 0.7071|00> + 0.7071|11>

Exact probabilities
  |00>   0.5000  #########################
  |01>   0.0000
  |10>   0.0000
  |11>   0.5000  #########################

Sampled measurement (10,000 shots)
  |00>   4,935  (0.4935)
  |11>   5,065  (0.5065)
  total variation distance from exact: 0.00650

Entanglement check: measure q0, then read q1
  qubits agreed in 1000/1000 trials (100.0%)
```

This matches the expected `(|00⟩ + |11⟩)/√2` exactly. The interesting result is
what is *absent*: |01⟩ and |10⟩ have identically zero amplitude. The two qubits
are individually random — each is 50/50 — yet perfectly correlated. Measuring
one collapses the shared state and determines the other instantly, which the
1000/1000 agreement confirms.

### 4.3 Measurement and collapse

We implement two distinct things both called "measurement":

1. **Reading the exact distribution.** Not physically realisable — no real
   quantum computer lets you read amplitudes — but it is what a simulator can do
   and what we verify correctness against.
2. **Sampling shots.** Drawing outcomes from the Born distribution, which is
   what real hardware gives you. Repeated shots *estimate* the distribution,
   converging as 1/√N.

**Partial measurement with collapse** is implemented properly: measuring one
qubit computes its marginal, samples an outcome, zeroes every amplitude
inconsistent with that outcome, and renormalises the survivors.

```python
idx[qubit] = 1 - outcome
psi[tuple(idx)] = 0.0     # kill the unobserved branch
state.renormalise()
```

This is the mechanism behind the Bell correlation above.

### 4.4 Other example circuits

**Quantum coin toss** (`examples/coin_toss.py`) — a single H. Also demonstrates
a *biased* coin via Ry(θ), giving P(1) = sin²(θ/2), which makes the point that
the amplitudes themselves set the odds rather than any external probability
parameter. Measured convergence:

| Shots | P(0) estimate | \|error\| | 1/√N |
|---|---|---|---|
| 10 | 0.60000 | 0.10000 | 0.31623 |
| 1,000 | 0.50500 | 0.00500 | 0.03162 |
| 100,000 | 0.50329 | 0.00329 | 0.00316 |
| 1,000,000 | 0.49984 | 0.00016 | 0.00100 |

**Quantum RNG** (`examples/qrng.py`) — H on every qubit gives a uniform
superposition over all 2ⁿ outcomes. Measured χ² = 8.723 against df = 7, i.e.
consistent with uniform.

An honest caveat, stated in the code as well: this *simulates* a QRNG. The
randomness actually comes from NumPy's PRNG sampling our computed distribution,
so it is no more physically random than any classical PRNG. On real hardware the
collapse itself supplies the entropy. What the simulator demonstrates correctly
is the circuit construction and the resulting uniform distribution.

---

## 5. KPI Documentation

All figures below are **measured**, not estimated. Raw data is in
`results/kpi_results.json`; plots are in `results/`.

Methodology notes applying throughout:

- Timings use `time.perf_counter` (monotonic, highest available resolution).
- Each measurement is repeated and we report the **median**, not the mean —
  medians are robust to OS scheduling spikes, which are frequent on a shared
  single-core container.
- Repetition count scales down with *n* (200 reps at n ≤ 12, 3 at n = 24).
- `validate=False` during scaling runs, since the normalisation check is itself
  an O(2ⁿ) pass and would roughly double the measured cost.

### 5.1 State vector size

**How measured:** directly, as `amplitudes.nbytes`, and cross-checked against
the analytic 16 × 2ⁿ.

**Why it matters:** this is the root cause of every other scaling limit. It is
not an implementation inefficiency — it is intrinsic to the physics. A general
*n*-qubit state genuinely requires 2ⁿ complex numbers to specify.

| Qubits | Amplitudes | Bytes |
|---|---|---|
| 1 | 2 | 32 B |
| 3 | 8 | 128 B |
| 10 | 1,024 | 16 KB |
| 20 | 1,048,576 | 16.8 MB |
| 24 | 16,777,216 | 268 MB |
| 26 | 67,108,864 | 1.07 GB |

### 5.2 Memory usage

**How measured:** process RSS delta via `psutil`, before and after allocating
and fully touching the array (so pages are actually resident, not just mapped).

**Why it matters:** it distinguishes intrinsic cost from implementation
overhead, which tells you whether optimisation would help.

| Qubits | Theory | Measured RSS Δ | Overhead |
|---|---|---|---|
| 16 | 1.05 MB | 0.79 MB | −25% |
| 20 | 16.8 MB | 12.6 MB | −25% |
| 22 | 67.1 MB | 67.1 MB | **0.0%** |
| 24 | 268.4 MB | 268.4 MB | **0.0%** |

At large *n* the measured memory matches theory to the byte — the Python object
overhead is a fixed ~100 bytes and becomes irrelevant. (The negative values at
smaller sizes are an artefact of the allocator reusing already-resident pages,
not a real saving.)

**Conclusion: there is no meaningful memory overhead to optimise away.** The
only lever is the 16 bytes per amplitude itself, or abandoning the dense
representation entirely.

### 5.3 Number of qubits supported

**How measured:** computed the largest *n* whose state vector fits in 45% of
available RAM (leaving headroom for the temporary that gate application
allocates), then *verified empirically* by allocating that register and running
H + CNOT on it end to end.

```
available RAM     : 3.77 GB
usable budget     : 1.70 GB
predicted maximum : 26 qubits (1.07 GB)
VERIFIED          : ran H + CNOT on 26 qubits in 857.4 ms
```

**26 qubits** on this machine. The task asks for 1–3; the architecture reaches
26 because gates are never materialised as full operators (§3.2).

Extrapolating shows why classical simulation stops:

| Qubits | Amplitudes | Memory |
|---|---|---|
| 30 | 1.07 × 10⁹ | 17.2 GB |
| 40 | 1.10 × 10¹² | 17.6 TB |
| 45 | 3.52 × 10¹³ | 562.9 TB |
| 50 | 1.13 × 10¹⁵ | **18.0 PB** |
| 60 | 1.15 × 10¹⁸ | 18.4 EB |

Each added qubit **doubles** the requirement. Around 50 qubits you exceed the
memory of the largest supercomputers on Earth — this is the concrete reason
"quantum advantage" is usually quoted near that threshold. It is not that the
algorithm is slow; it is that the state does not fit in the universe's available
silicon.

### 5.4 Probability correctness

**How measured:** four independent checks.

**(a) Against hand-derived analytic values.**

| Circuit | Max absolute error |
|---|---|
| H\|0⟩ (coin) | 1.110 × 10⁻¹⁶ |
| Bell Φ⁺ | 1.110 × 10⁻¹⁶ |
| GHZ-3 | 1.110 × 10⁻¹⁶ |
| uniform-3 | 5.551 × 10⁻¹⁷ |
| X\|0⟩ | **0** (exact) |

These errors are at the float64 machine epsilon (2.22 × 10⁻¹⁶). The simulator is
as accurate as double-precision arithmetic permits.

**(b) Norm preservation over deep random circuits.** Unitary gates must preserve
Σ|c|² = 1, so drift measures accumulated floating-point error.

| Qubits | Gates | \|1 − norm\| |
|---|---|---|
| 4 | 100 | 1.9 × 10⁻¹⁵ |
| 8 | 1,000 | 2.1 × 10⁻¹⁴ |
| 12 | 5,000 | 1.1 × 10⁻¹³ |

Error grows roughly as √(gates) — a random walk, as expected for independent
rounding errors. Even after 5,000 gates the drift is 10⁻¹³, utterly negligible.

**(c) Sampling convergence.** Total variation distance between sampled
frequencies and the exact distribution:

| Shots | TVD | 1/√N |
|---|---|---|
| 100 | 0.06000 | 0.10000 |
| 10,000 | 0.00480 | 0.01000 |
| 1,000,000 | 0.00002 | 0.00100 |

Tracks 1/√N, exactly as sampling theory predicts. This is *statistical* error
from finite shots, not simulator error — it is present on real hardware too.

**(d) Precision comparison — complex128 vs complex64.** Same 2,000-gate circuit
run in both precisions:

| Precision | Memory | Norm drift |
|---|---|---|
| complex128 | 0.02 MB | 8.7 × 10⁻¹⁴ |
| complex64 | 0.01 MB | **1.6 × 10⁻⁵** |

Max amplitude deviation: 1.1 × 10⁻⁶. Halving precision halves memory (worth one
extra qubit) but costs **nine orders of magnitude** of accuracy. This directly
informs the fixed-point discussion in §6.4.

### 5.5 Gate execution time

**How measured:** median of repeated `perf_counter`-timed applications of a
single gate to a freshly allocated state.

**Why it matters:** gates are the inner loop; everything else is bookkeeping.

| Qubits | H (ms) | X (ms) | CNOT (ms) | SWAP (ms) |
|---|---|---|---|---|
| 4 | 0.0102 | 0.0107 | 0.0108 | 0.0020 |
| 10 | 0.0131 | 0.0125 | 0.0134 | 0.0026 |
| 16 | 0.1545 | 0.1497 | 0.0879 | 0.0326 |
| 20 | 3.027 | 3.059 | 2.024 | 1.398 |
| 24 | 119.24 | 118.29 | 65.59 | 57.28 |

Two observations. CNOT is consistently **cheaper** than a single-qubit gate at
large *n*, because it only touches the control-|1⟩ half of the vector. And SWAP
is cheapest of all, being a pure axis permutation with no arithmetic.

### 5.6 Execution time and how it scales

**How measured:** wall-clock for a complete GHZ circuit (H then a CNOT chain,
*n* gates total).

| Qubits | Gates | Total (ms) |
|---|---|---|
| 2 | 2 | 0.024 |
| 10 | 10 | 0.168 |
| 16 | 16 | 2.268 |
| 20 | 20 | 65.17 |
| 24 | 24 | 2,758.51 |

**The scaling story is the most interesting result in this project**, and it has
two distinct regimes. Measuring the ratio of H-gate time between consecutive
qubit counts:

| n | H time (ms) | ratio vs n−1 |
|---|---|---|
| 4 | 0.01017 | 1.02 |
| 8 | 0.01180 | 1.06 |
| 12 | 0.01851 | 1.25 |
| 16 | 0.15454 | 2.37 |
| 20 | 3.02721 | 1.99 |
| 24 | 119.24 | 2.38 |

**Below ~12 qubits, the exponential is invisible.** The ratio sits near 1.0 and
gate time is essentially flat at ~0.01 ms. At n = 10 the array holds 1,024
complex numbers — NumPy processes that in microseconds, so runtime is dominated
entirely by **fixed Python interpreter and NumPy dispatch overhead**, not by the
arithmetic. Adding a qubit doubles work that is not the bottleneck, so nothing
changes.

**Above ~15 qubits the exponential takes over** and the ratio settles at 2.0–2.4.
Ratios *above* 2.0 are the genuinely interesting part: at n = 16 the state
vector is 1 MB and no longer fits comfortably in CPU cache, so the operation
becomes **memory-bandwidth-bound** rather than compute-bound. Each gate is a
streaming pass over a buffer too large to cache, and the penalty compounds. This
is the single most important observation for the FPGA discussion that follows:
**the bottleneck is memory traffic, not arithmetic.**

![Gate time scaling](../results/gate_time_scaling.png)

![Memory scaling](../results/memory_scaling.png)

---

## 6. Hardware and FPGA Discussion

This section is mandatory and no acceleration was implemented — what follows is
the engineering approach I would take, grounded in what §5 actually measured.

### 6.1 Memory requirements — the dominant constraint

The measurements in §5.6 established that beyond ~15 qubits this workload is
memory-bandwidth-bound, not compute-bound. That reframes the entire FPGA
question.

FPGA on-chip memory is small and fast. A mid-range Xilinx Artix-7 has roughly
2 MB of BRAM; a large Virtex UltraScale+ reaches ~50 MB of BRAM + URAM. Against
16 × 2ⁿ bytes:

| Qubits | State size | Fits in? |
|---|---|---|
| 12 | 65 KB | Artix-7 BRAM comfortably |
| 16 | 1.05 MB | Artix-7 BRAM, just |
| 20 | 16.8 MB | UltraScale+ URAM only |
| 24 | 268 MB | **External DDR required** |
| 30 | 17.2 GB | Beyond any single board |

The practical ceiling for a *fully on-chip* FPGA simulator is therefore around
**16–20 qubits**. That is genuinely useful — it covers the whole range where a
CPU is bottlenecked by Python overhead and cache misses.

The key insight: **if the state fits in BRAM, the FPGA wins decisively.** BRAM
delivers single-cycle deterministic access with no cache hierarchy, no misses
and no OS jitter. The cache-miss penalty that causes our ratio to exceed 2.0
above n = 16 simply does not exist. Beyond BRAM capacity you fall back to
external DDR and the FPGA loses most of its advantage, since it is then subject
to the same bandwidth wall as the CPU — with less mature prefetching.

### 6.2 Matrix operations

The operation to accelerate is not a general matrix multiply. As §3.2 showed, a
single-qubit gate reduces to a sweep over 2ⁿ⁻¹ **independent 2×2 complex
butterfly operations**, each pairing two amplitudes whose indices differ only in
the target bit:

```
c'[i]       = u00·c[i] + u01·c[i + 2^t]
c'[i + 2^t] = u10·c[i] + u11·c[i + 2^t]
```

One complex multiply-accumulate is 4 real multiplies and 2 real adds. Each
butterfly needs 8 real multiplies and 4 real adds. This maps beautifully onto
FPGA DSP48 slices — a device with 1,000+ DSPs could run ~100 butterflies
concurrently, versus one CPU core doing them essentially serially.

This structure is identical to the FFT butterfly, which means **decades of
existing FPGA FFT design work applies directly**: the same memory banking
schemes, the same pipelining strategies, the same conflict-avoidance tricks.
That is the strongest practical argument for the FPGA approach.

### 6.3 Parallelism opportunities

Four distinct levels, in descending order of value:

1. **Amplitude-level (best).** All 2ⁿ⁻¹ butterflies within one gate are
   completely independent — no data hazards, no ordering constraints. This is
   embarrassingly parallel and limited only by memory ports. Dual-port BRAM with
   correct banking (so the two amplitudes of each pair live in different banks)
   sustains one butterfly per cycle per unit.
2. **Pipelining.** A butterfly is a fixed 4–6 stage datapath: fetch, multiply,
   accumulate, write back. Fully pipelined, it retires one result per clock
   after fill. At 200 MHz with 100 parallel units that is 2 × 10¹⁰
   butterflies/sec — compare our measured CPU rate of ~1.4 × 10⁸/sec at n = 24.
   Roughly **100× headroom**.
3. **Gate fusion.** Consecutive single-qubit gates on the same qubit can be
   pre-multiplied into one 2×2 matrix on the host before upload, halving memory
   passes. Since we are bandwidth-bound, **this is worth more than adding
   compute**. Cheap to implement, purely a host-side optimisation.
4. **Circuit-level (limited).** Gates on disjoint qubits commute and could run
   concurrently, but they contend for the same state vector memory. Given
   bandwidth is already the bottleneck, this yields little.

The honest summary: **parallelising the arithmetic is easy and the arithmetic is
not the problem.** Effort belongs in memory architecture — banking, streaming
access patterns, and reducing the number of passes over the state vector.

### 6.4 Fixed-point vs floating-point arithmetic

This is where §5.4(d) pays off with real data rather than speculation.

IEEE-754 double precision on an FPGA is expensive: a float64 multiplier consumes
several DSP slices and multiple pipeline stages, and float64 is not natively
supported by DSP48 blocks at all. Fixed-point arithmetic maps to a single DSP
slice per multiply with far lower latency — realistically **4–8× more parallel
units for the same silicon**.

The measured cost of reduced precision:

| Format | Bits | Memory (n=20) | Norm drift, 2000 gates |
|---|---|---|---|
| complex128 | 128 | 16.8 MB | 8.7 × 10⁻¹⁴ |
| complex64 | 64 | 8.4 MB | 1.6 × 10⁻⁵ |
| Q1.15 fixed (est.) | 32 | 4.2 MB | ~10⁻³ (extrapolated) |

The argument **for** fixed-point is strong here, and rests on a property specific
to this workload: **amplitudes are bounded**. Normalisation guarantees
|c_k| ≤ 1 always. The catastrophic weakness of fixed-point — unpredictable
dynamic range — simply does not apply. A Q1.15 or Q2.30 format with the binary
point fixed just below 1.0 is well matched, and halving the word size directly
buys **one extra qubit** of capacity in the same BRAM.

The argument **against** is accumulation. Our complex64 result showed error
growing to 10⁻⁵ over 2,000 gates; fixed-point at 32 bits would be worse still,
and for deep circuits the error could grow until probabilities become
meaningless. A quantum state has no error-correcting structure to lean on.

**Recommended approach:** Q2.30 fixed-point (32-bit real and imaginary, 64-bit
per amplitude) for circuits under ~1,000 gates, with a periodic renormalisation
pass — cheap, since we already compute the norm — to arrest drift. Validate
against a float64 CPU reference, which is exactly what our test suite already
provides. For deep circuits, keep float32 and accept fewer parallel units.

### 6.5 Would this actually be worth building?

An honest assessment, since the answer is not an unqualified yes.

**Yes, for 12–20 qubits.** The state fits in BRAM, the butterfly structure maps
perfectly to DSP slices, and the deterministic single-cycle memory access
eliminates precisely the cache-miss penalty our benchmarks measured. A realistic
estimate is 50–100× over this single-core Python implementation, and perhaps
10–20× over optimised multithreaded C.

**No, beyond ~24 qubits.** Once the state exceeds on-chip memory you are
DDR-bandwidth-bound, which is the same wall the CPU hits — and a CPU has
sophisticated prefetchers and far more mature tooling. A GPU, with its much
higher memory bandwidth (HBM at ~1 TB/s versus DDR4 at ~25 GB/s), is the better
accelerator in that regime.

**The real ceiling is physics, not engineering.** No hardware defeats 2ⁿ. An
FPGA might buy 2–3 extra qubits over a CPU; a supercomputer buys perhaps 15
more. Neither changes the fundamental picture, which is why the answer to
simulating 100 qubits is not a faster classical simulator but an actual quantum
computer.

**Embedded systems** are a different proposition. A microcontroller with a few
hundred KB of RAM could host a 10–12 qubit simulator. That is genuinely useful
for education, for on-device algorithm prototyping, or as a control processor
sitting alongside real quantum hardware — a real "hybrid" workflow, where the
classical device handles parameter optimisation and the quantum device handles
the state.

---

## 7. Failure Analysis

Problems encountered during development and testing, what caused them, and how
they were resolved or would be.

### 7.1 Axis index shifting in controlled gates (bug, found and fixed)

**Symptom:** CNOT produced correct results for `cnot(0, 1)` but wrong results
for `cnot(1, 0)` on 3+ qubit registers.

**Cause:** slicing out the control axis reduces the tensor from *n* to *n−1*
dimensions, shifting every axis *after* the control down by one. Using the
original `target` index then addressed the wrong qubit.

**Fix:** `t_sub = target - 1 if control < target else target`.

**Why it was caught:** `test_cnot_reversed_control_target` and
`test_gate_on_middle_qubit_only` exist specifically to exercise this. A test
suite that only checked `cnot(0, 1)` on 2 qubits would have missed it entirely —
the bug is invisible in the most obvious test case. **Lesson: test the
non-adjacent, reversed-order, and middle-qubit cases, because those are where
index bookkeeping breaks.**

### 7.2 Floating-point precision accumulation (inherent, bounded)

**Symptom:** norm drifts from 1.0 by ~10⁻¹³ after 5,000 gates.

**Cause:** each gate performs ~2ⁿ floating-point operations, each rounding to
float64's ~10⁻¹⁶ relative precision. Errors accumulate as a random walk, growing
as √(gates).

**Assessment:** not a bug and not worth fixing at float64. 10⁻¹³ is 11 orders of
magnitude below any measurable probability. It becomes serious in reduced
precision — §5.4(d) showed complex64 drifting to 10⁻⁵ — which is why the
fixed-point recommendation in §6.4 includes periodic renormalisation.

### 7.3 Negative probabilities from round-off (defensive fix applied)

**Symptom:** `np.random.choice` occasionally rejected the probability vector as
invalid.

**Cause:** amplitudes that should be exactly zero end up at ±10⁻¹⁷ after
arithmetic; squaring can leave a tiny negative from subtraction round-off, and
the vector may not sum to exactly 1.0.

**Fix:** clip to non-negative and renormalise before sampling.

```python
probs = np.clip(probs, 0.0, None)
probs = probs / probs.sum()
```

### 7.4 Benchmark timing instability (methodology fix)

**Symptom:** early timing runs showed wild variance, including apparent
*speedups* when adding a qubit — physically impossible.

**Cause:** a single-core shared container with OS scheduling interference. Mean
timings were being skewed by occasional multi-millisecond stalls.

**Fix:** report the **median** over many repetitions rather than the mean, and
scale repetition count with *n*. The residual noise is visible in §5.6 as ratios
oscillating between 1.99 and 2.38 rather than sitting cleanly at 2.0.

### 7.5 Memory exhaustion at large registers (constraint, managed)

**Symptom:** allocating beyond ~26 qubits risks the OOM killer.

**Cause:** `tensordot` allocates a temporary of the same size as the state, and
`ascontiguousarray` may allocate another — so peak usage is 2–3× the state
vector.

**Mitigation:** the benchmark computes a memory budget at 45% of available RAM
and verifies empirically before committing. **Proper fix, not implemented:** an
in-place butterfly kernel that writes pairs back as it goes, eliminating the
temporary entirely and buying one more qubit. This is also exactly what an FPGA
implementation would do naturally.

### 7.6 Python overhead masking the exponential (measurement insight)

**Symptom:** gate time is flat from n = 1 to n ≈ 12, appearing to contradict the
O(2ⁿ) claim.

**Cause:** not a failure but a genuine and initially confusing finding. At small
*n* the actual arithmetic takes nanoseconds while Python function dispatch and
NumPy call overhead cost ~10 µs. The exponential is real but buried.

**Why it matters:** it would be easy to benchmark only up to 10 qubits, see flat
timings, and draw entirely the wrong conclusion. The sweep had to be pushed to
24 qubits before the asymptotic behaviour became visible. **Lesson: measure
across a range wide enough for the asymptotic regime to dominate the constant
factors.**

---

## 8. Limitations and Future Improvements

**Current limitations**

- **Dense representation only.** Memory is 16 × 2ⁿ regardless of how much
  structure the state has. A state with 4 non-zero amplitudes out of 16 million
  costs the same as a fully dense one.
- **Single-threaded.** No multiprocessing; NumPy does not parallelise these
  operations at this size.
- **Pure states only.** No density matrices, no noise, no decoherence — so it
  cannot model real hardware error.
- **No gate fusion or circuit optimisation.** Every gate is a separate full pass
  over the state vector.
- **Simulated randomness.** Measurement sampling uses NumPy's PRNG.

**Prioritised improvements**

1. **Gate fusion** (highest value/effort ratio). Pre-multiply consecutive
   single-qubit gates on the same qubit into one matrix. Since we are
   bandwidth-bound, halving the number of passes nearly halves runtime. Pure
   host-side work, no new numerics.
2. **In-place butterfly kernel.** Eliminate the `tensordot` temporary, cutting
   peak memory from ~3× to 1× the state vector and buying one extra qubit.
3. **Sparse representation.** Many useful circuits keep the state sparse — a
   GHZ state has exactly 2 non-zero amplitudes regardless of *n*. A hybrid that
   tracks sparsity and falls back to dense when it exceeds a threshold could
   handle far more qubits for structured circuits.
4. **Multithreading.** The butterfly loop is embarrassingly parallel; splitting
   the amplitude range across cores should scale near-linearly until memory
   bandwidth saturates.
5. **Noise modelling.** Density matrices (4ⁿ storage) or stochastic trajectory
   sampling would let the simulator model realistic hardware behaviour.

---

## 9. Conclusion

The simulator meets and exceeds the task requirements: it supports up to **26
qubits** (against the 2–3 requested), implements all mandatory gates plus five
optional ones, runs three complete example circuits, and is verified by **32
tests** against hand-derived analytic results with maximum error at machine
epsilon (1.1 × 10⁻¹⁶).

Three findings stand out:

**The representation choice dominates everything.** Storing the state as a flat
2ⁿ vector and contracting 2×2 gates against reshaped axes — rather than building
2ⁿ × 2ⁿ operators — is the difference between a 12-qubit toy and a 26-qubit
tool. That one decision is worth more than any micro-optimisation.

**The bottleneck is memory, not arithmetic.** The measured ratio exceeding 2.0
above 16 qubits revealed that once the state leaves CPU cache, the simulator is
bandwidth-bound. This reframes hardware acceleration entirely: the case for an
FPGA rests on BRAM's deterministic single-cycle access eliminating cache misses,
not on DSP slices doing multiplies faster.

**No amount of engineering defeats 2ⁿ.** An FPGA might buy 2–3 qubits, a
supercomputer perhaps 15. At 50 qubits the state vector is 18 petabytes. The
exponential is a property of quantum mechanics, not of the implementation —
which is precisely why quantum computers are interesting.

---

## Appendix A — Reproducing every figure

```bash
pip install -r requirements.txt
python tests/test_simulator.py        # 32/32 tests
python examples/bell_state.py         # §4.2
python examples/coin_toss.py          # §4.4
python examples/qrng.py               # §4.4
python benchmarks/kpi_benchmark.py    # all of §5, writes results/
```

Raw measurements: `results/kpi_results.json`.
Plots: `results/gate_time_scaling.png`, `memory_scaling.png`,
`circuit_time_scaling.png`.

## Appendix B — Complexity summary

| Operation | Time | Memory |
|---|---|---|
| State allocation | O(2ⁿ) | O(2ⁿ) |
| Single-qubit gate | O(2ⁿ) | O(2ⁿ) temp |
| Controlled gate | O(2ⁿ) | O(2ⁿ⁻¹) temp |
| SWAP | O(2ⁿ) | O(2ⁿ) temp |
| Probabilities | O(2ⁿ) | O(2ⁿ) |
| Sampling (k shots) | O(2ⁿ + k) | O(2ⁿ) |
| Single-qubit measure + collapse | O(2ⁿ) | O(1) |
| **Circuit of g gates** | **O(g · 2ⁿ)** | **O(2ⁿ)** |

Naive full-operator alternative: O(4ⁿ) time **and** O(4ⁿ) memory per gate.
