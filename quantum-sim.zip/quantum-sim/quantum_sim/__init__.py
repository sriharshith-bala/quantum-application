"""
quantum_sim — a small, from-scratch quantum circuit simulator.

Everything here is implemented directly on NumPy arrays: state vectors are
plain complex128 arrays and gates are explicit 2x2 matrices contracted against
them. No quantum SDK, no black-box simulator backend.

Quick start:

    from quantum_sim import Circuit, sample

    qc = Circuit(2).h(0).cnot(0, 1)      # Bell state
    result = qc.run()
    print(result.probabilities)          # {'00': 0.5, '11': 0.5}
    print(sample(result.state, shots=1000))
"""

from .state import QuantumState, DTYPE
from .gates import (
    I, X, Y, Z, H, S, T,
    apply_single_qubit_gate, apply_controlled_gate, apply_swap,
    x, y, z, h, cnot, cz, swap, is_unitary,
)
from .circuit import Circuit, Operation, RunResult
from .measurement import (
    probabilities, sample, measure_qubit, measure_all,
    counts_to_frequencies, total_variation_distance,
)

__version__ = "1.0.0"

__all__ = [
    "QuantumState", "DTYPE",
    "I", "X", "Y", "Z", "H", "S", "T",
    "apply_single_qubit_gate", "apply_controlled_gate", "apply_swap",
    "x", "y", "z", "h", "cnot", "cz", "swap", "is_unitary",
    "Circuit", "Operation", "RunResult",
    "probabilities", "sample", "measure_qubit", "measure_all",
    "counts_to_frequencies", "total_variation_distance",
]
