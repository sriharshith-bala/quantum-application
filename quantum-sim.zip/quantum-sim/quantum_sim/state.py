"""
state.py — Quantum state representation.

An n-qubit register is stored as a dense *state vector*: a 1-D NumPy array of
2**n complex amplitudes.

    |psi> = sum_{k=0}^{2^n - 1} c_k |k>

where k is the integer whose binary expansion gives the basis state. We use the
convention that **qubit 0 is the most significant bit**, i.e. for 3 qubits the
basis state |q0 q1 q2> = |101> corresponds to index k = 5.

Normalisation requires sum_k |c_k|^2 == 1, and the probability of measuring
basis state k is simply |c_k|^2 (the Born rule).

Superposition is represented implicitly: a state is in superposition whenever
more than one amplitude c_k is non-zero. There is no special "superposition
flag" — it falls straight out of the vector representation. Likewise
entanglement is represented by the state vector simply not being factorable
into a tensor product of single-qubit states; we never need to detect this
explicitly, because operating on the full 2**n vector handles it automatically.
"""

from __future__ import annotations

import numpy as np

# Amplitudes are complex128 (two float64s: 16 bytes per amplitude).
# This is the single most important choice for memory scaling — see the
# technical report's KPI section.
DTYPE = np.complex128

# Tolerance used for normalisation / unitarity checks.
TOL = 1e-10


class QuantumState:
    """Dense state-vector representation of an n-qubit register."""

    def __init__(self, num_qubits: int, amplitudes: np.ndarray | None = None):
        if num_qubits < 1:
            raise ValueError("num_qubits must be >= 1")
        self.num_qubits = num_qubits
        self.dim = 2 ** num_qubits

        if amplitudes is None:
            # Default initial state |00...0>: amplitude 1 on index 0.
            self.amplitudes = np.zeros(self.dim, dtype=DTYPE)
            self.amplitudes[0] = 1.0
        else:
            amplitudes = np.asarray(amplitudes, dtype=DTYPE).reshape(-1)
            if amplitudes.size != self.dim:
                raise ValueError(
                    f"expected {self.dim} amplitudes for {num_qubits} qubits, "
                    f"got {amplitudes.size}"
                )
            self.amplitudes = amplitudes.copy()
            self.validate()

    # ------------------------------------------------------------------ #
    # Construction helpers
    # ------------------------------------------------------------------ #

    @classmethod
    def from_basis_state(cls, num_qubits: int, index: int) -> "QuantumState":
        """Create the computational basis state |index>."""
        if not 0 <= index < 2 ** num_qubits:
            raise ValueError("basis index out of range")
        amps = np.zeros(2 ** num_qubits, dtype=DTYPE)
        amps[index] = 1.0
        return cls(num_qubits, amps)

    # ------------------------------------------------------------------ #
    # Probabilities
    # ------------------------------------------------------------------ #

    def probabilities(self) -> np.ndarray:
        """Born rule: P(k) = |c_k|^2 for every basis state k."""
        # abs()**2 on a complex array gives real float64 output.
        return np.abs(self.amplitudes) ** 2

    def probability_dict(self, min_prob: float = 1e-12) -> dict[str, float]:
        """Probabilities keyed by bitstring, omitting negligible entries."""
        probs = self.probabilities()
        out = {}
        for k, p in enumerate(probs):
            if p > min_prob:
                out[format(k, f"0{self.num_qubits}b")] = float(p)
        return out

    def marginal_probability(self, qubit: int) -> tuple[float, float]:
        """P(qubit == 0), P(qubit == 1), marginalising over all other qubits."""
        self._check_qubit(qubit)
        probs = self.probabilities().reshape([2] * self.num_qubits)
        axes = tuple(a for a in range(self.num_qubits) if a != qubit)
        marg = probs.sum(axis=axes)
        return float(marg[0]), float(marg[1])

    # ------------------------------------------------------------------ #
    # Validation / housekeeping
    # ------------------------------------------------------------------ #

    def norm(self) -> float:
        return float(np.sqrt(np.sum(np.abs(self.amplitudes) ** 2)))

    def validate(self) -> None:
        """Raise if the state is not normalised (catches implementation bugs)."""
        n = self.norm()
        if abs(n - 1.0) > 1e-8:
            raise ValueError(f"state is not normalised: norm = {n!r}")

    def renormalise(self) -> None:
        """Rescale to unit norm. Used after a measurement collapse."""
        n = self.norm()
        if n < TOL:
            raise ZeroDivisionError("cannot renormalise a zero state")
        self.amplitudes /= n

    def copy(self) -> "QuantumState":
        return QuantumState(self.num_qubits, self.amplitudes)

    def nbytes(self) -> int:
        """Exact bytes held by the amplitude array (16 * 2**n)."""
        return self.amplitudes.nbytes

    def _check_qubit(self, q: int) -> None:
        if not 0 <= q < self.num_qubits:
            raise ValueError(
                f"qubit index {q} out of range for {self.num_qubits}-qubit state"
            )

    # ------------------------------------------------------------------ #
    # Display
    # ------------------------------------------------------------------ #

    def to_ket(self, min_amp: float = 1e-9, precision: int = 4) -> str:
        """Human-readable Dirac notation, e.g. '0.7071|00> + 0.7071|11>'."""
        terms = []
        for k, c in enumerate(self.amplitudes):
            if abs(c) <= min_amp:
                continue
            label = format(k, f"0{self.num_qubits}b")
            if abs(c.imag) < 1e-12:
                coeff = f"{c.real:.{precision}f}"
            elif abs(c.real) < 1e-12:
                coeff = f"{c.imag:.{precision}f}j"
            else:
                coeff = f"({c.real:.{precision}f}{c.imag:+.{precision}f}j)"
            terms.append(f"{coeff}|{label}>")
        return " + ".join(terms) if terms else "0"

    def __repr__(self) -> str:
        return f"QuantumState({self.num_qubits} qubits, {self.to_ket()})"
