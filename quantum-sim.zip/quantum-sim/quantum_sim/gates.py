"""
gates.py — Gate matrices and the routines that apply them to a state vector.

Design note (this is the central engineering decision in the project):

A gate acting on an n-qubit register is formally a 2**n x 2**n unitary matrix,
and the naive way to apply it is a full matrix-vector product costing
O(4**n) time and O(4**n) memory just to *store* the operator. We never do that.

Instead we exploit the fact that a single-qubit gate is the identity on every
other qubit. Reshaping the flat 2**n state vector into an n-dimensional tensor
of shape (2, 2, ..., 2) makes each qubit its own axis, and applying the gate
becomes a contraction of the 2x2 matrix against just that one axis:

    psi = amplitudes.reshape([2] * n)
    psi = tensordot(U, psi, axes=([1], [target]))   # contract over target axis
    psi = moveaxis(psi, 0, target)                  # restore axis ordering

This costs O(2**n) time and allocates only O(2**n) scratch — an exponential
saving over building the full operator. A two-qubit controlled gate is handled
the same way, except we first slice out the half of the tensor where the
control qubit is |1> and apply the 2x2 matrix only to that sub-block, leaving
the control-|0> half untouched. Because NumPy basic slicing returns a *view*,
that write-back happens in place.

Convention: qubit 0 is the most significant bit, so for a 2-qubit register the
amplitude order is |00>, |01>, |10>, |11>.
"""

from __future__ import annotations

import numpy as np

from .state import DTYPE, TOL, QuantumState

SQRT1_2 = 1.0 / np.sqrt(2.0)

# --------------------------------------------------------------------------- #
# Single-qubit gate matrices
# --------------------------------------------------------------------------- #

I = np.array([[1, 0],
              [0, 1]], dtype=DTYPE)

# Pauli-X: the quantum NOT. Swaps the |0> and |1> amplitudes.
X = np.array([[0, 1],
              [1, 0]], dtype=DTYPE)

# Pauli-Y.
Y = np.array([[0, -1j],
              [1j, 0]], dtype=DTYPE)

# Pauli-Z: phase flip. Leaves |0> alone, multiplies |1> by -1.
# Note it does NOT change measurement probabilities of the computational
# basis on its own — only relative phase, which matters once you interfere
# the state again (e.g. with a second Hadamard).
Z = np.array([[1, 0],
              [0, -1]], dtype=DTYPE)

# Hadamard: maps |0> -> (|0> + |1>)/sqrt(2), creating an equal superposition.
H = SQRT1_2 * np.array([[1, 1],
                        [1, -1]], dtype=DTYPE)

# Phase gates (included for completeness; not required by the task).
S = np.array([[1, 0],
              [0, 1j]], dtype=DTYPE)

T = np.array([[1, 0],
              [0, np.exp(1j * np.pi / 4)]], dtype=DTYPE)

SINGLE_QUBIT_GATES = {
    "I": I, "X": X, "Y": Y, "Z": Z, "H": H, "S": S, "T": T,
}


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #

def is_unitary(U: np.ndarray, tol: float = 1e-12) -> bool:
    """Check U^dagger U == I. A non-unitary gate would break normalisation."""
    U = np.asarray(U, dtype=DTYPE)
    if U.ndim != 2 or U.shape[0] != U.shape[1]:
        return False
    return np.allclose(U.conj().T @ U, np.eye(U.shape[0], dtype=DTYPE), atol=tol)


def _validate_gate(U: np.ndarray) -> np.ndarray:
    U = np.asarray(U, dtype=DTYPE)
    if U.shape != (2, 2):
        raise ValueError(f"expected a 2x2 gate matrix, got shape {U.shape}")
    if not is_unitary(U):
        raise ValueError("gate matrix is not unitary")
    return U


# --------------------------------------------------------------------------- #
# Gate application
# --------------------------------------------------------------------------- #

def apply_single_qubit_gate(state: QuantumState, U: np.ndarray,
                            target: int, validate: bool = True) -> QuantumState:
    """
    Apply a 2x2 unitary to `target`, leaving all other qubits untouched.

    Cost: O(2**n) time, O(2**n) temporary allocation.
    """
    state._check_qubit(target)
    if validate:
        U = _validate_gate(U)
    else:
        U = np.asarray(U, dtype=DTYPE)

    n = state.num_qubits
    psi = state.amplitudes.reshape([2] * n)
    # Contract U's column index against the target axis. The resulting array
    # has the new (output) index sitting at axis 0, so move it back into place.
    psi = np.tensordot(U, psi, axes=([1], [target]))
    psi = np.moveaxis(psi, 0, target)
    state.amplitudes = np.ascontiguousarray(psi).reshape(-1)
    return state


def apply_controlled_gate(state: QuantumState, U: np.ndarray,
                          control: int, target: int,
                          validate: bool = True) -> QuantumState:
    """
    Apply a 2x2 unitary to `target`, but only on the branch of the
    superposition where `control` is |1>.

    This is what makes entanglement possible: the operation applied to one
    qubit depends on the value of another, so the resulting state can no
    longer be factored into independent single-qubit states.

    Cost: O(2**n) time; the control-|0> half of the vector is never touched.
    """
    state._check_qubit(control)
    state._check_qubit(target)
    if control == target:
        raise ValueError("control and target must be different qubits")
    if validate:
        U = _validate_gate(U)
    else:
        U = np.asarray(U, dtype=DTYPE)

    n = state.num_qubits
    psi = state.amplitudes.reshape([2] * n)  # view onto the same buffer

    # Slice out the sub-tensor where control == 1.
    idx = [slice(None)] * n
    idx[control] = 1
    idx = tuple(idx)
    sub = psi[idx]  # basic slicing -> view, shape (2,)*(n-1)

    # Removing the control axis shifts every axis after it down by one.
    t_sub = target - 1 if control < target else target

    sub_new = np.tensordot(U, sub, axes=([1], [t_sub]))
    sub_new = np.moveaxis(sub_new, 0, t_sub)

    psi[idx] = sub_new  # in-place write-back through the view
    return state


def apply_swap(state: QuantumState, q1: int, q2: int) -> QuantumState:
    """
    Exchange two qubits.

    Equivalent to three CNOTs, but implemented directly as an axis swap on the
    reshaped tensor, which is both clearer and cheaper (one pass instead of
    three).
    """
    state._check_qubit(q1)
    state._check_qubit(q2)
    if q1 == q2:
        return state

    n = state.num_qubits
    psi = state.amplitudes.reshape([2] * n)
    psi = np.swapaxes(psi, q1, q2)
    state.amplitudes = np.ascontiguousarray(psi).reshape(-1)
    return state


# --------------------------------------------------------------------------- #
# Named convenience wrappers
# --------------------------------------------------------------------------- #

def x(state: QuantumState, target: int) -> QuantumState:
    """Pauli-X (NOT)."""
    return apply_single_qubit_gate(state, X, target, validate=False)


def y(state: QuantumState, target: int) -> QuantumState:
    return apply_single_qubit_gate(state, Y, target, validate=False)


def z(state: QuantumState, target: int) -> QuantumState:
    """Pauli-Z (phase flip)."""
    return apply_single_qubit_gate(state, Z, target, validate=False)


def h(state: QuantumState, target: int) -> QuantumState:
    """Hadamard — creates superposition."""
    return apply_single_qubit_gate(state, H, target, validate=False)


def cnot(state: QuantumState, control: int, target: int) -> QuantumState:
    """Controlled-NOT: flip `target` iff `control` is |1>."""
    return apply_controlled_gate(state, X, control, target, validate=False)


def cz(state: QuantumState, control: int, target: int) -> QuantumState:
    """Controlled-Z."""
    return apply_controlled_gate(state, Z, control, target, validate=False)


def swap(state: QuantumState, q1: int, q2: int) -> QuantumState:
    return apply_swap(state, q1, q2)
