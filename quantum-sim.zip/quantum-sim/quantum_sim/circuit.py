"""
circuit.py — Build a circuit as an ordered list of gate operations, then run it.

The circuit object is deliberately just a *description*: it holds no state
vector itself. Calling `run()` allocates a fresh QuantumState and applies each
recorded operation in order. That separation means the same circuit can be run
repeatedly (e.g. for shot statistics or benchmarking) without rebuilding it.

Every `run()` records per-gate wall-clock timings, which feeds the KPI section
of the report directly.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from . import gates
from .state import QuantumState


@dataclass
class Operation:
    """A single recorded gate application."""
    name: str
    targets: tuple[int, ...]
    matrix: np.ndarray | None = None  # for custom user-supplied gates

    def __str__(self) -> str:
        qs = ", ".join(f"q{t}" for t in self.targets)
        return f"{self.name}({qs})"


@dataclass
class RunResult:
    """Everything produced by one execution of a circuit."""
    state: QuantumState
    total_time_s: float
    gate_times_s: list[float] = field(default_factory=list)
    gate_names: list[str] = field(default_factory=list)

    @property
    def probabilities(self) -> dict[str, float]:
        return self.state.probability_dict()

    @property
    def mean_gate_time_s(self) -> float:
        return float(np.mean(self.gate_times_s)) if self.gate_times_s else 0.0

    def summary(self) -> str:
        lines = [
            f"final state : {self.state.to_ket()}",
            f"probabilities: {self._fmt_probs()}",
            f"total time  : {self.total_time_s * 1e6:.2f} us",
            f"mean gate   : {self.mean_gate_time_s * 1e6:.2f} us",
            f"state vector: {self.state.dim} amplitudes "
            f"({self.state.nbytes()} bytes)",
        ]
        return "\n".join(lines)

    def _fmt_probs(self) -> str:
        return ", ".join(f"|{k}>: {v:.4f}" for k, v in self.probabilities.items())


class Circuit:
    """An ordered sequence of gate operations on an n-qubit register."""

    def __init__(self, num_qubits: int):
        if num_qubits < 1:
            raise ValueError("num_qubits must be >= 1")
        self.num_qubits = num_qubits
        self.operations: list[Operation] = []

    # ------------------------------------------------------------------ #
    # Circuit construction (each returns self so calls can be chained)
    # ------------------------------------------------------------------ #

    def _check(self, *qubits: int) -> None:
        for q in qubits:
            if not 0 <= q < self.num_qubits:
                raise ValueError(
                    f"qubit {q} out of range for {self.num_qubits}-qubit circuit"
                )
        if len(set(qubits)) != len(qubits):
            raise ValueError("a gate cannot act on the same qubit twice")

    def x(self, target: int) -> "Circuit":
        self._check(target)
        self.operations.append(Operation("X", (target,)))
        return self

    def y(self, target: int) -> "Circuit":
        self._check(target)
        self.operations.append(Operation("Y", (target,)))
        return self

    def z(self, target: int) -> "Circuit":
        self._check(target)
        self.operations.append(Operation("Z", (target,)))
        return self

    def h(self, target: int) -> "Circuit":
        self._check(target)
        self.operations.append(Operation("H", (target,)))
        return self

    def cnot(self, control: int, target: int) -> "Circuit":
        self._check(control, target)
        self.operations.append(Operation("CNOT", (control, target)))
        return self

    def cz(self, control: int, target: int) -> "Circuit":
        self._check(control, target)
        self.operations.append(Operation("CZ", (control, target)))
        return self

    def swap(self, q1: int, q2: int) -> "Circuit":
        self._check(q1, q2)
        self.operations.append(Operation("SWAP", (q1, q2)))
        return self

    def custom(self, name: str, matrix: np.ndarray, target: int) -> "Circuit":
        """Apply an arbitrary user-supplied 2x2 unitary."""
        self._check(target)
        if not gates.is_unitary(matrix):
            raise ValueError(f"custom gate {name!r} is not unitary")
        self.operations.append(Operation(name, (target,), np.asarray(matrix)))
        return self

    # ------------------------------------------------------------------ #
    # Execution
    # ------------------------------------------------------------------ #

    def run(self, initial_state: QuantumState | None = None,
            validate: bool = True) -> RunResult:
        """
        Execute the circuit and return the final state plus timing data.

        `validate=True` re-checks normalisation after every gate. That is a
        genuine correctness guard (a buggy gate shows up immediately as a norm
        drift) but costs an extra O(2**n) pass per gate, so the benchmarks turn
        it off.
        """
        state = initial_state.copy() if initial_state is not None \
            else QuantumState(self.num_qubits)

        if state.num_qubits != self.num_qubits:
            raise ValueError(
                f"initial state has {state.num_qubits} qubits, "
                f"circuit expects {self.num_qubits}"
            )

        gate_times: list[float] = []
        gate_names: list[str] = []

        t_start = time.perf_counter()
        for op in self.operations:
            t0 = time.perf_counter()
            self._apply(state, op)
            gate_times.append(time.perf_counter() - t0)
            gate_names.append(op.name)

            if validate:
                state.validate()
        total = time.perf_counter() - t_start

        return RunResult(state=state, total_time_s=total,
                         gate_times_s=gate_times, gate_names=gate_names)

    @staticmethod
    def _apply(state: QuantumState, op: Operation) -> None:
        name = op.name
        if name == "X":
            gates.x(state, op.targets[0])
        elif name == "Y":
            gates.y(state, op.targets[0])
        elif name == "Z":
            gates.z(state, op.targets[0])
        elif name == "H":
            gates.h(state, op.targets[0])
        elif name == "CNOT":
            gates.cnot(state, op.targets[0], op.targets[1])
        elif name == "CZ":
            gates.cz(state, op.targets[0], op.targets[1])
        elif name == "SWAP":
            gates.swap(state, op.targets[0], op.targets[1])
        elif op.matrix is not None:
            gates.apply_single_qubit_gate(state, op.matrix, op.targets[0],
                                          validate=False)
        else:
            raise ValueError(f"unknown operation: {name}")

    # ------------------------------------------------------------------ #
    # Display
    # ------------------------------------------------------------------ #

    def depth(self) -> int:
        """Number of gates (not true circuit depth — no parallelism model)."""
        return len(self.operations)

    def state_vector_bytes(self) -> int:
        return 16 * (2 ** self.num_qubits)  # complex128 = 16 bytes

    def diagram(self) -> str:
        """
        Crude ASCII circuit diagram. One column per gate, so it reads
        left-to-right in execution order.
        """
        n = self.num_qubits
        rows = [[f"q{q}: "] for q in range(n)]
        for op in self.operations:
            if len(op.targets) == 1:
                t = op.targets[0]
                for q in range(n):
                    rows[q].append(f"[{op.name:^4}]" if q == t else "------")
            else:
                c, t = op.targets[0], op.targets[1]
                lo, hi = min(c, t), max(c, t)
                for q in range(n):
                    if q == c:
                        rows[q].append("--\u25cf---" if op.name != "SWAP" else "--\u00d7---")
                    elif q == t:
                        sym = {"CNOT": "\u2295", "CZ": "\u25cf", "SWAP": "\u00d7"}.get(op.name, "?")
                        rows[q].append(f"--{sym}---")
                    elif lo < q < hi:
                        rows[q].append("--\u2502---")
                    else:
                        rows[q].append("------")
        return "\n".join("".join(r) for r in rows)

    def __str__(self) -> str:
        ops = " ".join(str(o) for o in self.operations)
        return f"Circuit({self.num_qubits} qubits): {ops}"
