"""
measurement.py — Probability-based measurement and state collapse.

Two distinct things get called "measurement", and the task asks for both:

1. **Reading out the probability distribution.** This is not physical — no real
   quantum computer lets you read amplitudes — but it is the thing a simulator
   can do and is what we check correctness against analytically.

2. **Sampling.** Draw actual shot outcomes from that distribution, which is
   what real hardware gives you. Repeated shots let you *estimate* the
   distribution, converging as 1/sqrt(shots).

We also implement **partial measurement with collapse**: measuring a single
qubit projects the state onto the observed outcome and renormalises, so any
entangled partner qubit is instantly constrained too. That's the mechanism
behind the Bell-state correlation.
"""

from __future__ import annotations

from collections import Counter

import numpy as np

from .state import QuantumState


def probabilities(state: QuantumState) -> np.ndarray:
    """Full probability distribution over all 2**n basis states."""
    return state.probabilities()


def sample(state: QuantumState, shots: int = 1024,
           rng: np.random.Generator | None = None) -> dict[str, int]:
    """
    Draw `shots` measurement outcomes from the Born distribution.

    Returns a dict of bitstring -> count. We sample all shots in one vectorised
    call rather than looping, which matters at high shot counts.
    """
    if shots < 1:
        raise ValueError("shots must be >= 1")
    rng = rng or np.random.default_rng()

    probs = state.probabilities()
    # Guard against tiny negative values from floating-point round-off and
    # renormalise so the vector is a valid probability distribution.
    probs = np.clip(probs, 0.0, None)
    total = probs.sum()
    if total <= 0:
        raise ValueError("state has zero total probability")
    probs = probs / total

    outcomes = rng.choice(state.dim, size=shots, p=probs)
    width = state.num_qubits
    counts = Counter(format(int(k), f"0{width}b") for k in outcomes)
    return dict(sorted(counts.items()))


def measure_qubit(state: QuantumState, qubit: int,
                  rng: np.random.Generator | None = None) -> int:
    """
    Measure a single qubit in the computational basis and **collapse** the
    state in place. Returns the observed bit (0 or 1).

    Implementation: compute the marginal P(qubit=1), sample the outcome, then
    zero out every amplitude inconsistent with it and renormalise the survivors.
    """
    state._check_qubit(qubit)
    rng = rng or np.random.default_rng()

    p0, p1 = state.marginal_probability(qubit)
    outcome = 1 if rng.random() < p1 / (p0 + p1) else 0

    n = state.num_qubits
    psi = state.amplitudes.reshape([2] * n)
    idx = [slice(None)] * n
    idx[qubit] = 1 - outcome
    psi[tuple(idx)] = 0.0  # kill the branch that was not observed

    state.renormalise()
    return outcome


def measure_all(state: QuantumState,
                rng: np.random.Generator | None = None) -> str:
    """
    Measure every qubit at once, collapsing to a single basis state.
    Returns the observed bitstring.
    """
    rng = rng or np.random.default_rng()
    probs = np.clip(state.probabilities(), 0.0, None)
    probs = probs / probs.sum()

    k = int(rng.choice(state.dim, p=probs))
    state.amplitudes[:] = 0.0
    state.amplitudes[k] = 1.0
    return format(k, f"0{state.num_qubits}b")


def counts_to_frequencies(counts: dict[str, int]) -> dict[str, float]:
    """Normalise shot counts into estimated probabilities."""
    total = sum(counts.values())
    if total == 0:
        return {}
    return {k: v / total for k, v in sorted(counts.items())}


def total_variation_distance(p: dict[str, float], q: dict[str, float]) -> float:
    """
    TVD between two distributions over bitstrings: (1/2) * sum |p_i - q_i|.

    Used as the "probability correctness" KPI — it gives a single bounded
    number in [0, 1] measuring how far sampled frequencies sit from the exact
    analytic distribution.
    """
    keys = set(p) | set(q)
    return 0.5 * sum(abs(p.get(k, 0.0) - q.get(k, 0.0)) for k in keys)
